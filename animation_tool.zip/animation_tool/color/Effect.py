import bpy
import random
import time
import bmesh
from mathutils.bvhtree import BVHTree

# Define a custom property name for storing object names as metadata
METADATA_SPHERE = "md_sphere"


class Effector:
    """Handle effector properties."""
    
    def __init__(self, obj, type):
        self.object = obj
        self.type = type
        
    def get_color(self, my_tool,color=(0.0, 0.0, 0.0), on=True):
        if on:
            if(self.type == "BRIGHTNESS"):
                    brightness_ratio = my_tool.brightness_ratio
                    color_new = (color[0] * brightness_ratio, color[1] * brightness_ratio, color[2] * brightness_ratio)
                    return color_new
            elif(self.type == "VOLUME"):
                    return random.choice(self.object.material_slots).material.diffuse_color
            elif(self.type == "RANDOM"):
                    upper = my_tool.upper
                    lower = my_tool.lower
                    random_ratio = random.uniform(upper,lower)
                    color_new = (color[0] * random_ratio,color[1] * random_ratio,color[2] * random_ratio)
                    return color_new
            else:
                    return color
        else:
            return (0.0, 0.0, 0.0)


class Drone:
    """Store animation properties associated with each drone."""

    def __init__(self, s):
        self.sphere = s # UV sphere associated with drone
        self.inside = {} # drone's inside/outside status on frame f
        self.original_colors = {} # original color of drone on frame f
        self.color_frames = [] # list of tuples representing color keyframes
        self.on_frame = {} # whether drone is switched on or off on frame f
        
    def set_original_color(self, f):
        """Store drone's original color on frame f."""
        self.original_colors[f] = self.sphere.active_material.diffuse_color[:]
        
    def set_inside(self, f, effector):
      
        point = self.sphere.matrix_world.translation
        bm = bmesh.new()
        bm.from_mesh(effector.data)
        bmesh.ops.transform(bm, matrix=effector.matrix_world, verts=bm.verts)
        bvh = BVHTree.FromBMesh(bm)
        nearest, normal, _, _ = bvh.find_nearest(point)
        self.inside[f] = normal.dot(nearest - point) >= 0.0

    def set_color_frame(self, f, color):
        """Add color keyframe to drone's list of color keyframes."""
        self.color_frames.append([f, (color[0], color[1], color[2])])


class my_properties(bpy.types.PropertyGroup):

    End: bpy.props.IntProperty(
       name="End",
       description="end_frame",
       default=0,
    )

    retain: bpy.props.BoolProperty(
        name="Retain",
        description="Retain color after effector leaves",
        default=False
    )

    reveal: bpy.props.BoolProperty(
        name="Reveal",
        description="Reveal formation",
        default=False
    )

    transition_frames: bpy.props.IntProperty(
       name="transition_frames",
       description="number of frames between transitions",
       default=1,
    )

    brightness_ratio: bpy.props.FloatProperty(
        name="brightness_ratio",
        description="Brightness ratio",
        default=1.0,
        min=0,
        max=2,)
    upper: bpy.props.FloatProperty(
        name = "up",
        description = "upper limit of the color",
        default = 2.0,
        min=0,
        max=2,
    )
    lower: bpy.props.FloatProperty(
        name = "lower",
        description = "lower limit of the color",
        default = 0.0,
        min=0,
        max=2,
    )
    
    effector_type: bpy.props.EnumProperty(
        items=(('VOLUME', 'Volume', ""),
               ('BRIGHTNESS', 'Brightness', ""),
               ('RANDOM', 'Random_Brightness', "")),
        name="Type",
        description="Effector Type"
    )

    Start: bpy.props.IntProperty(
       name="Start",
       description="start_frame",
       default=0,
    )

    End: bpy.props.IntProperty(
       name="End",
       description="end_frame",
       default=0,
    )


class effector_setup(bpy.types.Panel):
    bl_label = "Effector"
    bl_idname = "BLENDER_PT_effector_setup"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Color'

    def draw(self, context):

        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool.effector

        row = layout.row(align=True)
        row.prop(mytool, "effector_type")
        
        if mytool.effector_type == "BRIGHTNESS":
            row = layout.row(align=True)
            row.prop(mytool, "brightness_ratio")
        if mytool.effector_type == "RANDOM":
            row = layout.row(align=True)
            row = layout.row(align=True)
            row.prop(mytool, "lower")
            row.prop(mytool, "upper")
            
        row = layout.row(align=True)
        row.prop(mytool, "retain")
        row.prop(mytool, "reveal")
        row = layout.row(align=True)
        row.prop(mytool, "transition_frames")
        row = layout.row(align=True)
        row.prop(mytool,"Start")
        row = layout.row(align=True)
        row.prop(mytool,"End")
        self.layout.operator('mesh.color_effector')


class color_Effector(bpy.types.Operator):
    """Transfer effector color to all drones inside effector."""

    bl_label = "Color Effector"
    bl_idname = "mesh.color_effector"

    def execute(self, context):
        start_time2 = time.time()

        mytool = bpy.context.scene.my_tool.effector

        spheres = [obj for obj in bpy.data.objects if METADATA_SPHERE in obj]
        num_on = len(spheres)
        on_list = [True] * num_on + [False] * (len(spheres) - num_on)

        for obj in bpy.data.objects:
            if obj in spheres:
                obj.select_set(True)
            else:
                obj.select_set(False)

        drones = [Drone(s) for s in spheres]

        effector = bpy.context.active_object
        effector_type = mytool.effector_type
        
        e = Effector(effector, effector_type)

        start = mytool.Start
        end = mytool.End + 1
        frames = mytool.transition_frames
        if frames < 1:
            self.report({'ERROR'},'Transition frame should be greater than 0')
            return {'CANCELLED'}
        upper = mytool.upper
        lower = mytool.lower
        upper = round(upper, 2)
        lower = round(lower, 2)
        if (upper - lower < 0.01):
            self.report({'ERROR'},'Value of Upper should be atleast 0.01 greater than lower')
            return {'CANCELLED'}
        color_retain = mytool.retain
        reveal = mytool.reveal

        on_frame = []
        
        # Build dictionaries storing which drones will be on or off on which frame
        for f in range(start, end + frames):
            random.shuffle(on_list)
            for i in range(len(drones)):
                drones[i].on_frame[f] = on_list[i]

        # Build dictionaries of original colors and inside/outside status of each drone on each frame
        for f in range(start, end + frames):
            bpy.context.scene.frame_set(f)
            for d in drones:
                d.set_original_color(f)
                d.set_inside(f, effector)


        for d in drones:
            f = start + 1
            inside_flag = d.inside[f] # inside_flag tells if d was previously inside or outside the effector
            while f < end:
                if d.inside[f]: # if d is now inside the effector
                    
                    if not inside_flag: # if d was not inside the effector previously, and is now inside
                        # Switch from original color to effector color
                        color_new = e.get_color(mytool,color=d.original_colors[f + frames], on=d.on_frame[f])
                        color_old = d.original_colors[f]
                        
                        new_f = f + frames
                        
                        d.set_color_frame(f, color_old)
                        d.set_color_frame(new_f, color_new)
                        
                        f = new_f

                    else: # if d was inside the effector previously, and is still inside
                        new_f = f + frames
                        color_new = e.get_color(mytool,color=d.original_colors[f + frames], on=d.on_frame[f])
                        d.set_color_frame(new_f, color_new)
                        f = new_f
                            
                    inside_flag = True

                else: # if d is now outside the effector
                    if inside_flag and not color_retain: # if d was previously inside, and is now outside
                        # Switch from effector color back to original color
                        if len(d.color_frames) == 0: # if the drone started inside the effector
                            color_new = e.get_color(mytool,color=d.original_colors[f])
                            d.set_color_frame(f, color_new) # do not begin transition till drone moves out
                        
                        color_old = d.original_colors[f + frames]
                        d.set_color_frame(f + frames, color_old)

                        f = f + frames
                    else: # if d was previously outside, and is still outside
                        # Do nothing much
                        f = f + 1
                    inside_flag = False


        def set_object_color(obj, color, f):
            """Insert a color and shadernode keyframe for an object's active material.

            obj -- the object
            color -- the color of the active material on the keyframe
            f -- the frame at which to insert a keyframe
            """
            
            #solid_color
            obj.active_material.diffuse_color[0] = color[0]
            obj.active_material.diffuse_color[1] = color[1]
            obj.active_material.diffuse_color[2] = color[2]
            obj.active_material.keyframe_insert(data_path="diffuse_color", frame=f)

        # Step through frames and insert the relevant color keyframes on each frame
        for f in range(start, end + frames):
            for d in drones:
                if f == start and reveal:
                    set_object_color(d.sphere, (0.0, 0.0, 0.0), start)
                if len(d.color_frames):
                    if d.color_frames[0][0] == f:
                        if not reveal:
                            set_object_color(d.sphere, d.color_frames[0][1], f)
                        else:
                            set_object_color(d.sphere, d.color_frames[0][1], end - (f - start))
                        d.color_frames = d.color_frames[1:]

        end_time2 = time.time()
        execution_time2 = end_time2 - start_time2
        print(f"Execution time for export: {execution_time2} seconds")


        return {'FINISHED'}