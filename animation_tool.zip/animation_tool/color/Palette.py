import bpy
import bpy.utils.previews


def update_callback(self, context):
    if self.active:
        for i in self.id_data.my_tool.palette:
            if i.name != self.name:
                i.active = False

    bpy.palette_color=self.color


class my_properties(bpy.types.PropertyGroup):
    active: bpy.props.BoolProperty(default=False, update=update_callback)
    icon: bpy.props.IntProperty()
    
    color: bpy.props.FloatVectorProperty(
         name = "color",
         subtype = "COLOR",
         default = (1.0,1.0,1.0,1.0),
         size = 4)
    
        
class palette(bpy.types.Panel):
    """Palette GUI """
    bl_label = "palette"
    bl_idname = "BLENDER_PT_palette"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Color"

    def draw(self, context):
        layout = self.layout
        scene= context.scene

        if bpy.context.scene.create_custom_layout:
            self.draw_custom_layout(layout,scene)
        else:
            self.draw_default_layout(layout,scene)

    def draw_custom_layout(self,layout,scene):
        layout.label(text="Custom Layout")
        layout.operator("object.palette_setup", text="Palette Color Option")

    def draw_default_layout(self,layout,scene):
        col = layout.column(align=True)
        row = col.row(align=True)
        global active_item 
        active_item = None
        layout.operator("object.color_drone_palette", text="Palette Color")
        layout.operator("object.disable_palette", text=" Disable Palette")
        row = col.row(align=True)
        for idx, item in enumerate(scene.my_tool.palette, start=1):
            row.prop(item, "active", icon_value=item.icon, icon_only=True)
            if item.active == True:
                active_item = item
            if idx % 13 == 0:
                row = col.row(align=True)
            
        if active_item:
            row = layout.row()
            r, g, b, a = active_item.color
            row.label(text=f"Active item: {r:.2f} {g:.2f} {b:.2f} {a:.2f}")
 
        
class palette_setup(bpy.types.Operator):
    """Palette setup """
    bl_idname = "object.palette_setup"
    bl_label = "Palette Setup"

    def execute(self, context):
       
       for obj in bpy.context.selected_objects:
            if not obj.data.materials:
                self.report({'ERROR'},'Material is not present in atleast one of the objects')
                return {'CANCELLED'}
    
       if not (bpy.context.selected_objects):
            self.report({'ERROR'},'Please select atleast one sphere')
            return {'CANCELLED'}
       if hasattr(bpy.context.scene.my_tool, "palette"):
        bpy.context.scene.my_tool.palette.clear()       
       
       preview_collections={}
       pal = bpy.utils.previews.new()
       color_255=[
    (255, 0, 0),(255, 128, 0),(255, 255, 0),(128, 255, 0),(0, 255, 0),(0,255, 128),(0, 255, 255),(0, 128, 255),(0, 0, 255),(127, 0, 255),(255, 0, 255),(255, 0, 127),(76.5,76.5,76.5),
    (255,12.75,12.75),(255,133.875,12.75),(255,255,12.75),(133.875,255,12.75),(12.75,255,12.75),(12.75,255,133.875),(12.75,255,255),(12.75,133.875,255),(12.75,12.75,255),(133.875,12.75,255),(255,12.75,255),(255,12.75,133.875),(102,102,102),
    (255,25.5,25.5),(255,140.25,26),(255,255,25.5),(140.25,255,25.5),(25.5,255,25.5),(25.5,255,140.25),(25.5,255,255),(25.5,140.25,255),(25.5,25.5,255),(140.25,25.5,255),(255,25.5,255),(255,25.5,140.25),(127,127,127),
    (255, 51, 51),(255, 153, 51),(255, 255, 51),(153, 255, 51),(51, 255, 51),(51,255, 153),(51,255, 255),(51, 153, 255),(51, 51, 255),(153, 51, 255),(255, 51, 255),(255, 51, 153),(160, 160,160),
    (255, 102, 102),(255,178,102),(255, 255, 102),(178, 255, 102),(102, 255, 102),(102,255,178),(102, 255, 255),(102, 178, 255),(102, 102, 255),(178, 102, 255),(255, 102, 255),(255, 102, 178),(192, 192,192),
    (255, 153, 153),(255, 204, 153),(255,255,153) ,(204, 255, 153),(153, 255, 153),(102,255, 178),(153, 255, 255),(153,204,255),(153, 153, 255),(204, 153, 255),(255, 153, 255),(255, 153, 204),(224, 224, 224),
    (255,204, 204),(255, 229, 204),(255, 255, 204),(229,255, 204),(204, 255, 204),(204, 255, 229),(204, 255, 255),(204,229,255),(204,204,255),(229,204,255),(255,204,255),(255,204,229),(255,255,255)]
       color=[]
       
       for i in range(len(color_255)):
        x=color_255[i][0]/255
        y=color_255[i][1]/255
        z=color_255[i][2]/255
        color.append((x,y,z,1))
        
       size = 50, 50
       for i in range(len(color)):
         color_name = f"Color1{i}"
         pixels = [*color[i]] * size[1] * size[1]
         icon = pal.new(color_name) # name has to be unique!
         icon.icon_size = size
         icon.is_icon_custom = True
         icon.icon_pixels_float = pixels
        
        
         # add the item to the collection
         color_item = bpy.context.scene.my_tool.palette.add()
         color_item.name = color_name
         color_item.color = color[i]
         color_item.icon = pal[color_name].icon_id
    
       preview_collections["main"] = pal
    
       bpy.context.scene.create_custom_layout=False
       return {'FINISHED'}


class color_drone_palette(bpy.types.Operator):
    """Set color of active material of selected objects using palette."""

    bl_label = "Color"
    bl_idname = "object.color_drone_palette"

    def execute(self,context):
        scene = context.scene   
        mytool = scene.my_tool.palette
       
        if not (bpy.context.selected_objects):
            self.report({'ERROR'},'Please select atleast one sphere')
            return {'CANCELLED'}
        
        if not active_item:
            self.report({'ERROR'},'Please select color from the color palette')
            return {'CANCELLED'}
        for obj in bpy.context.selected_objects:
                
            obj.active_material.diffuse_color = bpy.palette_color
        return {'FINISHED'}


class disable_palette(bpy.types.Operator):
    """disable palette."""

    bl_label = "Color"
    bl_idname = "object.disable_palette"

    def execute(self,context):
        bpy.context.scene.create_custom_layout=True
        return {'FINISHED'}
     
     
     