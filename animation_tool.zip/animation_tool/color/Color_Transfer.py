import bpy
import json
import os
import time

# Define a custom property name for storing object names as metadata
METADATA_SPHERE = "md_sphere"
METADATA_EMPTY = "md_empty"


# Function to get RGBA data
def get_rgba(frame, material):
    if material:
        animation_data = material.animation_data
        if not animation_data or not animation_data.action:
            return material.diffuse_color[:]
        return [curve.evaluate(frame) for curve in animation_data.action.fcurves]
    return [0.0, 0.0, 0.0, 1]

def export_colors(self):

    data = {}
    selected_objects = bpy.context.selected_objects

    if not selected_objects:
        self.report({'ERROR'},'Please select all the Empties')
        return {'CANCELLED'}
    
    bpy.ops.object.select_by_type(type='MESH')

    selected_spheres = bpy.context.selected_objects

    prefetch = {}
    # # to prefetch the sphere 
    for obj in selected_spheres:  # Access object by name
        prefetch[obj.get(METADATA_SPHERE)] = obj

    current_object_index = 0 
    total_objects = len(selected_objects)
    progress_update_interval = 3  # Set the desired update interval in seconds
    last_update_time = time.time()

    for obj in selected_objects:
        # Update progress percentage
        if time.time() - last_update_time >= progress_update_interval:
            progress_percentage = current_object_index / total_objects * 100
            print(f'Percentage Completed: {progress_percentage:.2f}%', end='\r')
            last_update_time = time.time()
            current_object_index += 1

        if METADATA_EMPTY not in obj:
            self.report({'ERROR'},'Please select Empties only')
            return {'CANCELLED'}
   
        # Check if the empty object has the metadata
        drone_name = str(obj.get('drone')) + 'S'
        drone = prefetch.get(drone_name)
        
        if drone:
            if drone.active_material:
                material = drone.active_material

                if not material.animation_data.action:
                    self.report({'ERROR'},'Color keyframe is not present in atleast one sphere')
                    return {'CANCELLED'}
        
        color_keyframes = material.animation_data.action.fcurves.find('diffuse_color')
        if color_keyframes:
            empty_name = obj[METADATA_EMPTY].split('E')[0]
            for keyframe in color_keyframes.keyframe_points:
                frame_number = int(keyframe.co[0])
                diffuse_color = get_rgba(frame_number, material)
                color = [diffuse_color[0], diffuse_color[1], diffuse_color[2], diffuse_color[3]]
                data.setdefault(empty_name, {})[frame_number] = color

    custom_filename = bpy.context.scene.my_tool.color_transfer.custom_filename
    with open(global_path + f"{custom_filename}.txt", "w") as f:
        f.write(json.dumps(data, indent=1))


def import_colors(self,offset,global_path1):

    material_dict = {}
    selected_objects = bpy.context.selected_objects

    if not selected_objects:
        self.report({'ERROR'},'Please select all the Empties')
        return {'CANCELLED'}
    
    bpy.ops.object.select_by_type(type='MESH')

    selected_spheres = bpy.context.selected_objects

    prefetch = {}
    # # to prefetch the sphere 
    for obj in selected_spheres:  # Access object by name
        prefetch[obj.get(METADATA_SPHERE)] = obj
    
    with open(global_path1) as file:
        # Read the contents of the file
        material_dict = json.load(file)
        current_object_index = 0 
        total_objects = len(selected_objects)
        progress_update_interval = 3  # Set the desired update interval in seconds
        last_update_time = time.time()

        for obj in selected_objects:
            # Update progress percentage
            if time.time() - last_update_time >= progress_update_interval:
                progress_percentage = current_object_index / total_objects * 100
                print(f'Percentage Completed: {progress_percentage:.2f}%', end='\r')
                last_update_time = time.time()
                current_object_index += 1

            if METADATA_EMPTY not in obj:
                self.report({'ERROR'},'Please select Empties only')
                return {'CANCELLED'}
            
            drone_name = str(obj.get('drone')) + 'S'
            drone = prefetch.get(drone_name)

            if drone:
                if drone.active_material:
                    material = drone.active_material

                    empty_search = obj[METADATA_EMPTY].split('E')[0]
                    if empty_search in material_dict:
                        value = material_dict[empty_search]
                        if material.name not in bpy.data.materials:
                            bpy.data.materials[material.name] = material

                        for frame_key in value:
                            frame = float(frame_key) + offset
                            color = value[frame_key]

                            # Set the color value and insert keyframe
                            material.diffuse_color = color
                            material.keyframe_insert(data_path="diffuse_color", frame=frame)


class my_properties(bpy.types.PropertyGroup):
      offset: bpy.props.IntProperty(
      name="offset",
      default=0,
      description="Offset in frames",
      )
      folder_path: bpy.props.StringProperty(name="Export Folder Path",
                                        description="Export Folder Path",
                                        default=os.path.expanduser("~/Desktop"),
                                        subtype="DIR_PATH"
                                        )
      file_path: bpy.props.StringProperty(name="Import File Path",
                                        description="Import File Path",
                                        subtype="FILE_PATH"
                                        )
      custom_filename: bpy.props.StringProperty(
        name="Custom Filename",
        description="Custom filename for export",
        default="colors",
    )
   

class color_Transfer(bpy.types.Panel):
    bl_label = "Color Transfer"
    bl_idname = "BLENDER_PT_color_Transfer"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Color'

    def draw(self, context):
        tool = bpy.context.scene.my_tool.color_transfer
        row = self.layout.row(align=True)
        row.prop(tool, "folder_path")
        row = self.layout.row(align=True)
        row.prop(tool, "custom_filename")
        row = self.layout.row(align=True)
        self.layout.operator('mesh.export_framess')
        row = self.layout.row(align=True)
        row.prop(tool, "file_path")
        row = self.layout.row(align=True)
        row.prop(tool, "offset")
        self.layout.operator('mesh.import_framess')
        Path = tool.folder_path
        global global_path
        global_path = bpy.path.abspath(Path)
        Path1 = tool.file_path
        global global_path1
        global_path1 = bpy.path.abspath(Path1)


class Import(bpy.types.Operator):   
    bl_label = "Import"
    bl_idname = "mesh.import_framess"

    def execute(self,context):
        if not global_path1:
            self.report({'ERROR'},'Please select the exported color file')
            return {'CANCELLED'}
        tool = bpy.context.scene.my_tool.color_transfer
        offset = tool.offset
        start_time1 = time.time()
        import_colors(self,offset,global_path1)
        end_time1 = time.time()
        execution_time1 = end_time1 - start_time1
        print(f"\nExecution time for import: {execution_time1} seconds")
        return {'FINISHED'}


class Export(bpy.types.Operator):    
    bl_label = "Export"
    bl_idname = "mesh.export_framess"

    def execute(self, context):
        tool = bpy.context.scene.my_tool.color_transfer
        start_time2 = time.time()
        export_colors(self)
        end_time2 = time.time()
        execution_time2 = end_time2 - start_time2
        print(f"\nExecution time for export: {execution_time2} seconds")
        return {'FINISHED'}

