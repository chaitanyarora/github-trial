import bpy

# Define a custom property name for storing object names as metadata
METADATA_SPHERE = "md_sphere"


def set_node_frame_color():
    for obj in bpy.context.editable_objects:
          if METADATA_SPHERE in obj:
             obj.active_material.node_tree.nodes["Emission"].inputs[0].default_value = obj.active_material.diffuse_color
    return 0.02

class my_properties(bpy.types.PropertyGroup):
      object_color: bpy.props.FloatVectorProperty(
      name="object_color",
      subtype='COLOR',
      default=(1.0, 1.0, 1.0),
      min=0.0, max=1.0,
      description="color picker",
      )
      

class actual_color_setup(bpy.types.Panel):
    bl_label = "Solid color"
    bl_idname = "BLENDER_PT_actual_color_setup"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Color'

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool.solid_color
        
        row = layout.row(align=True)
        row.prop(mytool,"object_color")
        self.layout.operator('object.color_drone')
        row = layout.row(align=True)
        self.layout.operator('object.color_keyframe')
        row = layout.row(align=True)    
        if bpy.context.scene.node_shader_thread:
            self.layout.operator('object.unactive_node')
        else:
            self.layout.operator('object.active_node')
            

class color_drone(bpy.types.Operator):
    """Set color of active material of selected objects."""
    bl_label = "Color"
    bl_idname = "object.color_drone"
    def execute(self,context):
        scene = context.scene
        mytool = scene.my_tool.solid_color
        selected_objects = bpy.context.selected_objects
        if not selected_objects:
            self.report({'ERROR'},'Please select atleast one mesh')
            return {'CANCELLED'}
        for obj in selected_objects:
            if METADATA_SPHERE in obj:
                if not obj.data.materials:
                    mat = bpy.data.materials.new(name="MaterialName"+obj[METADATA_SPHERE])
                    obj.data.materials.append(mat)
            else:
                if obj.type=='EMPTY':
                    self.report({'ERROR'},'Please select mesh only')
                    return {'CANCELLED'}
                mat = bpy.data.materials.new(name="MaterialName"+obj.name)
                obj.data.materials.append(mat)
        for obj in selected_objects:
            obj.active_material.diffuse_color = (mytool.object_color[0],mytool.object_color[1],mytool.object_color[2],1)
        return {'FINISHED'}


class color_keyframe(bpy.types.Operator):
    """Insert color keyframes on current frame for all selected objects."""

    bl_label = "Color Keyframe"
    bl_idname = "object.color_keyframe"

    def execute(self,context):
        scene = context.scene
        mytool = scene.my_tool.solid_color

        if not (bpy.context.selected_objects):
            self.report({'ERROR'},'Please select atleast one sphere')
            return {'CANCELLED'}

        for obj in bpy.context.selected_objects:
            if not obj.data.materials:
                self.report({'ERROR'},'Material is not present in atleast one of the objects')
                return {'CANCELLED'}
            obj.active_material.keyframe_insert(data_path='diffuse_color')
 
        return {'FINISHED'}


class active_node(bpy.types.Operator):
    bl_label = "Enable node"
    bl_idname = "object.active_node"

    def execute(self,context):
        scene = context.scene
        mytool = scene.my_tool.solid_color

        for obj in bpy.context.editable_objects:
     
            if METADATA_SPHERE in obj:
                material = obj.active_material
                material.use_nodes = True

                if material.node_tree.nodes.get('Principled BSDF'):
                    x = material.node_tree.nodes.get('Principled BSDF')

                if material.node_tree.nodes.get('Emission'):
                    x = material.node_tree.nodes.get('Emission')

                material.node_tree.nodes.remove(x)
                material_output = material.node_tree.nodes.get('Material Output')
                diffuse = material.node_tree.nodes.new('ShaderNodeEmission')
                diffuse.inputs['Color'].default_value = (0, 0, 0, 1)
                material.node_tree.links.new(material_output.inputs[0], diffuse.outputs[0])
                obj.active_material = material

        if bpy.context.scene.node_shader_thread == 0:
            bpy.app.timers.register(set_node_frame_color)
            bpy.context.scene.node_shader_thread = 1 
        return {'FINISHED'}
    

class unactive_node(bpy.types.Operator):
    bl_label = "Disable node"
    bl_idname = "object.unactive_node"

    def execute(self,context):
        scene = context.scene
        mytool = scene.my_tool.solid_color

        for obj in bpy.context.editable_objects:

            if METADATA_SPHERE in obj:
                obj.active_material.use_nodes=False
        bpy.context.scene.node_shader_thread=0    
        bpy.app.timers.unregister(set_node_frame_color)
        return {'FINISHED'}
