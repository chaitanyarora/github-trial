import bpy
from animation_tool.helper_function  import  *
import bmesh
import re

# Define a custom property name for storing object names as metadata
METADATA_EMPTY="md_empty"
METADATA_SPHERE = "md_sphere"

class concept_setup(bpy.types.Panel):
    bl_label = "Concept"
    bl_idname = "BLENDER_PT_concept_setup"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Concept'

    def draw(self, context):
        self.layout.operator('object.add_concept')
        self.layout.operator('object.delete_concept')


class add_concept(bpy.types.Operator):
    """Add drones at locations of selected empties."""

    bl_label = "Add Concept"
    bl_idname = "object.add_concept"
    def execute(self,context):
        scene = context.scene
        mytool = scene.my_tool

        selected_objects = bpy.context.selected_objects
        if selected_objects:
            if any(x for x in selected_objects if METADATA_EMPTY not in x) == True:
                self.report({'ERROR'},'Please select empties only')
                return {'CANCELLED'}

        elif not selected_objects:
            self.report({'ERROR'},'Please select at least one empty')
            return {'CANCELLED'}

        coll = bpy.context.scene.collection
        if "CONCEPT" in bpy.data.collections:
            new_coll = bpy.data.collections["CONCEPT"]
            last_added_object_name = new_coll.objects[-1].name

            match = re.match(r'^(\d+)S', last_added_object_name)
            if match:
                idx = int(match.group(1))

        else:
            new_coll = bpy.data.collections.new(name="CONCEPT")
            bpy.context.scene.collection.children.link(new_coll)
            idx = 0
        
        for obj in selected_objects:
          if METADATA_EMPTY in obj:
            mesh = bpy.data.meshes.new(name=f"{str(idx+1)}")
            bm = bmesh.new()
            bmesh.ops.create_icosphere(bm, subdivisions=1, radius=0.2)
            bm.to_mesh(mesh)
            bm.free()
                      
            while(True):
                if f"{str(idx+1)}S" in new_coll.objects:
                    idx += 1
                else:
                    break
            
            sphere_object = bpy.data.objects.new(name=f"{str(idx+1)}", object_data=mesh)
            sphere_object.location = (obj.matrix_world.translation.x, obj.matrix_world.translation.y, obj.matrix_world.translation.z)

            sphere_object.lock_scale[0] = True
            sphere_object.lock_scale[1] = True
            sphere_object.lock_scale[2] = True
            new_coll.objects.link(sphere_object)
      
            if sphere_object.name in coll.objects:
                coll.objects.unlink(sphere_object)

            sphere_object[METADATA_SPHERE] = f"{str(idx + 1)}S"
            
            idx=idx+1

        return {'FINISHED'}

class delete_concept(bpy.types.Operator):
    """Remove all spheres."""

    bl_label = "Delete Concept"
    bl_idname = "object.delete_concept"
    def execute(self,context):
        scene = context.scene
        for obj in scene.objects:
           if METADATA_SPHERE  in obj:
             bpy.data.objects.remove(obj)

        # Check if the collection exists
        if "CONCEPT" in bpy.data.collections:
            # Get the collection
            concept_collection = bpy.data.collections["CONCEPT"]
            
            # Unlink all objects from the collection
            for obj in concept_collection.objects:
                concept_collection.objects.unlink(obj)
            
            # Remove the collection
            bpy.data.collections.remove(concept_collection)

        return {'FINISHED'}
