import bpy
import time
from animation_tool.helper_function  import  *

METADATA_EMPTY="md_empty"


class my_properties(bpy.types.PropertyGroup):
    radio_buttons: bpy.props.EnumProperty(
        items=[
            ('FOR', 'Forward', 'To move mesh in forward direction'),
            ('REV', 'Reverse', 'To move mesh in reverse direction'),
        ],
        name="Follow_path"
    )
    
    num_meshes: bpy.props.IntProperty(
       name="Meshes",
       description="Number of meshes",
       default=8,
    )

    cycles: bpy.props.FloatProperty(
       name="Cycles",
       description="number of cycles around path",
       default=1.0,
    )
    
    start: bpy.props.IntProperty(
       name="Frame Start",
       description="Start frame for path",
       default=1,
    )
    
    end: bpy.props.IntProperty(
       name="Frame End",
       description="End frame for path",
       default=100,
    )
    
                 
class follow_path_setup(bpy.types.Panel):
    bl_label = "Follow Path"
    bl_idname = "BLENDER_PT_follow_path_setup"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Follow_Path'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        mytool = scene.my_tool.follow_path         
        layout.prop(mytool, "radio_buttons", expand=True)
        
        row = layout.row(align=True)
        row.prop(mytool, "num_meshes")
        
        row = layout.row(align=True)
        row.prop(mytool, "cycles")
        
        row = layout.row(align=True)
        row.prop(mytool, "start")
        
        row = layout.row(align=True)
        row.prop(mytool, "end")
        
        self.layout.operator('mesh.select_and_duplicate')
        self.layout.operator('mesh.follow_path_offset')
        self.layout.operator('mesh.follow_path_keyframe')
        self.layout.operator('mesh.single_empty')
        
           
class follow_path_keyframe(bpy.types.Operator):
    bl_label = "Follow Path Keyframe"
    bl_idname = "mesh.follow_path_keyframe"
    
    def execute(self, context):
        mytool = context.scene.my_tool.follow_path
        selected_objects = bpy.context.selected_objects
        
        # Input Validation
        if not bpy.context.selected_objects:
                self.report({'ERROR'},'Please select the CURVE')
                return {'CANCELLED'}
            
        if len(bpy.context.selected_objects) > 0:
            if bpy.context.selected_objects[0].type != 'CURVE':
                self.report({'ERROR'},'Please select the CURVE')
                return {'CANCELLED'}
        start_time2 = time.time()
            
        if selected_objects:
            # Set the curve object as the active object
            curve_object = selected_objects[0]
            context.view_layer.objects.active = curve_object
            cu = curve_object.data
            start = mytool.start
            end = mytool.end
            frame=context.scene.frame_current
            
            # Ensure that the curve has eval_time property
            if hasattr(cu, 'eval_time'):
                cu.eval_time = (frame / (end - start))*100
                cu.keyframe_insert(data_path='eval_time', frame=context.scene.frame_current)
                
        end_time2 = time.time()
        execution_time2 = end_time2 - start_time2
        print(f"Execution time for Follow Path Keyframe : {execution_time2} seconds")       
        
        return {'CANCELLED'}
    
        
class follow_path_offset(bpy.types.Operator):
    bl_label = "Follow Path"
    bl_idname = "mesh.follow_path_offset"
    
    def execute(self, context):
        mytool = context.scene.my_tool.follow_path
        reverse = mytool.radio_buttons == 'REV'
        num_meshes = mytool.num_meshes
        cycles = mytool.cycles
        start = mytool.start
        end = mytool.end
        
        # Input Validation
        if not bpy.context.selected_objects:
                self.report({'ERROR'},'Please select the CURVE')
                return {'CANCELLED'}
            
        if len(bpy.context.selected_objects) > 0:
            if bpy.context.selected_objects[0].type != 'CURVE':
                self.report({'ERROR'},'Please select CURVE only')
                return {'CANCELLED'}
            
        if mytool.num_meshes<=0:
            self.report({'ERROR'},'Number of meshes must be greater than 0')
            return {'CANCELLED'}
        
        if (end - start < 1):
            self.report({'ERROR'},'Value of frame end should be atleast 1 greater than frame start')
            return {'CANCELLED'}
        start_time2 = time.time()
        
        bpy.context.scene.formation_index =  bpy.context.scene.formation_index+1
        formation =  bpy.context.scene.formation_index
        if reverse:
            start, end = end, start
            
        # Selected curve
        curve_object = bpy.context.selected_objects[0]
        cu = curve_object.data
        cu.eval_time = 0
        cu.keyframe_insert('eval_time', frame=start)
        
        def is_curve_closed(curve_object):
            return curve_object.type == 'CURVE' and any(spline.use_cyclic_u for spline in curve_object.data.splines)
        if is_curve_closed(curve_object):
            cu.eval_time = 100 * cycles
        else:
            cu.eval_time = 100 + (100 - 100/num_meshes)
        cu.keyframe_insert('eval_time', frame=end)
        
        # Create a collection for empties
        empties_collection = bpy.data.collections.new(name="MESH_SET "+str(formation))
        bpy.context.scene.collection.children.link(empties_collection)

        for i in range(num_meshes):

            bpy.ops.object.select_all(action='DESELECT')
            try :
                if selected_mesh:
                    pass
            except:
                self.report({'ERROR'},'Please select the mesh first')
                return {'CANCELLED'}

            bpy.context.view_layer.objects.active = selected_mesh

            selected_mesh.hide_set(False)
            selected_mesh.hide_viewport = False 
            
            bpy.context.view_layer.objects.active.location = (0,0,0)
            bpy.context.view_layer.objects.active.select_set(True)
            bpy.ops.object.duplicate(linked=False)
            
            mesh_object = bpy.context.active_object
            mesh_object.scale = (.1,.1,.1)
            mesh_object.name = str(i+1)+"MS"+str(bpy.context.scene.formation_index)
            if mesh_object.type == 'EMPTY':
                mesh_object[METADATA_EMPTY] = str(i+1)+"ME"+str(bpy.context.scene.formation_index)
            bpy.context.collection.objects.unlink(mesh_object)
            empties_collection.objects.link(mesh_object)
            bpy.context.view_layer.objects.active = mesh_object
            
            # Add a Follow Path constraint to the empty object
            follow_path_constraint = mesh_object.constraints.new(type='FOLLOW_PATH')
            follow_path_constraint.target = curve_object
            follow_path_constraint.use_curve_follow = True
            follow_path_constraint.use_curve_radius = True
            follow_path_constraint.use_fixed_location = False
            
            # Calculate equidistant offset
            offset = curve_object.data.path_duration / num_meshes * i
            
            # Animate the offset to make the object move along the path
            follow_path_constraint.offset = offset
        bpy.data.objects.remove(selected_mesh, do_unlink=True)
        
        end_time2 = time.time()
        execution_time2 = end_time2 - start_time2
        print(f"Execution time for Follow Path : {execution_time2} seconds") 
        return {'FINISHED'}
    
    
class follow_path_select_mesh(bpy.types.Operator):
    bl_label = "Select Mesh"
    bl_idname = "mesh.select_and_duplicate"
    
    def execute(self, context):
        
        if not bpy.context.selected_objects:
            self.report({'ERROR'},'Please select the Mesh')
            return {'CANCELLED'}
        
        mytool = context.scene.my_tool.follow_path
        global selected_mesh
        
        start_time2 = time.time()
        
        selected_mesh = bpy.context.selected_objects[0]            
        selected_mesh.hide_viewport = True
        
        end_time2 = time.time()
        execution_time2 = end_time2 - start_time2
        print(f"Execution time for Select Mesh : {execution_time2} seconds")
        
        return {'CANCELLED'}
    
class add_single_empty(bpy.types.Operator):
    bl_label = "Add Single Empty"
    bl_idname = "mesh.single_empty"
    
    def execute(self, context):
        
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        empty = bpy.context.object
        empty.name = "Empty"

        return {'CANCELLED'}
    
