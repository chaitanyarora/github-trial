import bpy
import bmesh

class my_properties(bpy.types.PropertyGroup):
    total_spheres: bpy.props.IntProperty(
       name="TD",
       description="Total no. of spheres",
       default=3,
    )

    total_rows: bpy.props.IntProperty(
       name="X",
       description="No. of rows",
       default=2,
    )

    x_diff: bpy.props.FloatProperty(
       name="X_diff",
       description="X distance between the spheres",
       default=1,
    )

    y_diff: bpy.props.FloatProperty(
       name="Y_diff",
       description="Y distance between the spheres",
       default=1,
    )

class drone_setup(bpy.types.Panel):
    bl_label = "Drone Setup (Metadata Beta 1.5.2)"
    bl_idname = "BLENDER_PT_drone_setup"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Formation'

    def draw(self, context):
        layout = self.layout
        scene=context.scene
        mytool = context.scene.my_tool.drone
        
        row = layout.row(align=True)
        row.prop(mytool,"total_spheres")
        row.prop(mytool, "total_rows")

        row = layout.row(align=True)
        row.prop(mytool,"x_diff")
        row.prop(mytool, "y_diff")

        self.layout.operator('object.reset_scene') # Reset
        self.layout.operator('object.sphere_grid') # Sphere Grid

class reset_scene(bpy.types.Operator):
    """Remove all objects from scene"""

    bl_label = "Reset "
    bl_idname = "object.reset_scene"

    def execute(self,context):
        scene = context.scene
        
        for obj in scene.objects: 
            # Check if the object has any materials assigned
            if obj.material_slots: 
                # Delete all materials assigned to the object
                for material_slot in obj.material_slots:
                    bpy.data.materials.remove(material_slot.material)
                # Clear the material slots
                obj.data.materials.clear()

        collections = bpy.data.collections
        for collection in collections:
            for obj in collection.objects:
                bpy.data.objects.remove(obj)
            bpy.data.collections.remove(collection, do_unlink=True)

        bpy.context.scene.formation_index=0
        scene = context.scene
        for object_ in scene.objects:
           bpy.data.objects.remove(object_)

        return {'FINISHED'}
    
    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_confirm(self, event)

class sphere_grid(bpy.types.Operator):
    """Create new sphere grid"""

    bl_label = "Sphere Grid "
    bl_idname = "object.sphere_grid"

    def execute(self,context):
        mytool = context.scene.my_tool.drone

        # Input validation
        if ((mytool.total_spheres<=0) or (mytool.total_rows<=0) or (mytool.x_diff<=0) or (mytool.y_diff<=0)):
            self.report({'ERROR'},'Total spheres and total rows and total x_distance and total y_distance must be greater than 0')
            return {'CANCELLED'}
       
        new_coll = bpy.data.collections.new(name="SPHERE")
        new_col2 = bpy.data.collections.new(name="EMPTY_LAND")

        bpy.context.scene.collection.children.link(new_coll)
        bpy.context.scene.collection.children.link(new_col2)

        # Add UV spheres at grid positions
        grid_locations = list()
        total_spheres = mytool.total_spheres
        sphere_radius = 0.2
      
        for every_count in range(total_spheres):
            x=(every_count%mytool.total_rows)*mytool.x_diff
            y=(every_count//mytool.total_rows)*mytool.y_diff
            grid_locations.append([x,y])

        for idx in range(mytool.total_spheres):
            x, y = grid_locations[idx]
            mesh = bpy.data.meshes.new(name=f"{str(idx+1)}")
            bm = bmesh.new()
            bmesh.ops.create_icosphere(bm, subdivisions=1, radius=sphere_radius)        
            bm.to_mesh(mesh)
            bm.free()

            sphere_object = bpy.data.objects.new(name=f"{str(idx+1)}", object_data=mesh)
            sphere_object.location = (x,y,1)
            sphere_object.lock_scale[0] = True
            sphere_object.lock_scale[1] = True
            sphere_object.lock_scale[2] = True
            new_coll.objects.link(sphere_object)

            # Define a custom property name for storing object names as metadata
            METADATA_SPHERE = "md_sphere"
            METADATA_EMPTYLAND = "md_emptyland"
            
            # Store sphere name in metadata
            sphere_object[METADATA_SPHERE] = f"{str(idx + 1)}S"

        # Add empties at grid locations
        # Assign names and move into collection "EMPTY_LAND"
        for idx in range(mytool.total_spheres):
            x, y = grid_locations[idx]
            empty = bpy.data.objects.new('Empty', None)
            empty.name = str(idx+1)+"EL" 
            empty.location = (x, y, 10)
            empty["rotation"] = (0, 0, 0)
            new_col2.objects.link(empty)

            # Store empty land name in metadata
            empty[METADATA_EMPTYLAND] = str(idx + 1) + "E0"


        return {'FINISHED'}
    



