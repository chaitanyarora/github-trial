import bpy
from animation_tool.helper_function  import  *


# Define a custom property name for storing object names as metadata
METADATA_SPHERE = "md_sphere"
METADATA_EMPTY="md_empty"
METADATA_EMPTYLAND = "md_emptyland"


class formation_trajectory(bpy.types.Panel):
    bl_label = "Formation Trajectory"
    bl_idname = "BLENDER_PT_formation_trajectory"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Formation'

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        self.layout.operator('object.assign_vertex_group_to_empties')
        self.layout.operator('object.collision_avoidance')
        self.layout.operator('object.unhidden')
        row = layout.row(align=True)
        self.layout.operator('object.initial_keyframe')
        self.layout.operator('object.final_keyframe')


class initial_keyframe(bpy.types.Operator):
    bl_label = "Intial Keyframe"
    bl_idname = "object.initial_keyframe"
    def execute(self,context):
        scene = context.scene

        selected_objects = bpy.context.selected_objects
        if not selected_objects:
            self.report({'ERROR'}, 'Please select only the Empties')
            return {'CANCELLED'}
        
        if any(x for x in selected_objects if METADATA_EMPTY not in x) == True:
            self.report({'ERROR'},'Please select only the Empties')
            return {'CANCELLED'}

        drone_empty = {}
        for empty in selected_objects:
            if (METADATA_EMPTY in empty) and (empty["drone"] > 0):
                drone_empty[str(empty["drone"])+'S'] = empty
            elif (METADATA_EMPTYLAND in empty) and (empty["drone"] > 0):
                drone_empty[str(empty["drone"])+'S'] = empty

        for obj in bpy.context.scene.objects:
            if METADATA_SPHERE in obj:
                empty = drone_empty.get(obj[METADATA_SPHERE])

                if empty is not None and empty.get("checkpoint") == 1:
                    obj.constraints.new('COPY_LOCATION')
                    obj.constraints["Copy Location"].target = empty
                    obj.constraints["Copy Location"].influence = 0
                    obj.constraints["Copy Location"].keyframe_insert(data_path='influence')
                    empty["checkpoint"]=2
        return {'FINISHED'}
    

class assign_vertex_group_to_empties(bpy.types.Operator):
    bl_label = "Assign Vertex Group"
    bl_idname = "object.assign_vertex_group_to_empties"

    def execute(self,context):
        scene = context.scene
        obj=bpy.context.object

        """Create new vertex group on formation mesh and assign each vertex to an empty."""
        empty=[]
        formation=[]
        
        for obj in bpy.context.selected_objects:
          # Get empties from list of selected objects
          if METADATA_EMPTY in obj :
              empty.append(obj)
          else:
              formation.append(obj) # <<<<<<<<<< in future should be alerted to select one formation at a time

        if not (empty and formation):
            self.report({'ERROR'},'Please select both empties and mesh ')
            return {'CANCELLED'}

        for k in range(len(empty)):
            a = int(empty[k][METADATA_EMPTY].split('E')[0])

            group=formation[0].vertex_groups.new( name = str(a-1))
            group.add([a-1], 1, 'ADD')
            empty[k]["vertex"]=a-1 
       
        """Stick empties to vertices on formation using object constraints."""
        empty=[]
        formation=[]
       
        for obj in bpy.context.selected_objects:
          # Get empties from list of selected objects
          if METADATA_EMPTY in obj : 
              empty.append(obj)
          else:
              formation.append(obj)
            
        # Add location constraints to empties
        for k in range(len(empty)):
            empty[k].constraints.new('COPY_LOCATION')
            empty[k].constraints["Copy Location"].target = formation[0]
            empty[k].constraints["Copy Location"].subtarget = str(empty[k]["vertex"])
            empty[k].constraints["Copy Location"].influence = 1 
        return {'FINISHED'}
    

class collision_avoidance(bpy.types.Operator):
    """Apply collision avoidance algorithm to selected spheres and empties."""

    bl_label= "Collision Avoidance"
    bl_idname = "object.collision_avoidance"

    def execute(self,context):
        empty=[]
        sphere=[]
        drone=[]
        target=[]
        mesh = 0

        for obj in bpy.context.selected_objects:
            if METADATA_EMPTY in obj:
                empty.append(obj)
            elif METADATA_SPHERE in obj:
                sphere.append(obj)
            elif METADATA_EMPTYLAND in obj:
                empty.append(obj)              
            else:
                obj.name[0].isalpha()
                mesh+=1

        for i in range(len(empty)):
            target.append(coor_xyz(empty[i]))

        for i in range(len(sphere)):
            drone.append(coor_xyz(sphere[i]))

        if (not (empty and sphere)) or (mesh!=0):
            self.report({'ERROR'},'Please select empties and spheres only ')
            return {'CANCELLED'}

        # >>>>>>>>>  ALERT:  n(target) = n(drone)  
        data = assign_hungarian(drone,target)

        for i in range(len(data)):

          j= data[i][1]

          a=sphere[i][METADATA_SPHERE].split('S')[0]

          empty[j]["drone"] = int(a) # drone id

          empty[j]["checkpoint"] = 1 # checkpoint increment

          empty[j].hide_set(True)

          sphere[i].hide_set(True)

        return {'FINISHED'}
    

class unhidden(bpy.types.Operator):
    """Unhide all empties and spheres."""

    bl_label = "Unhidden"
    bl_idname = "object.unhidden"

    def execute(self,context):
        scene = context.scene
        for obj in bpy.context.scene.objects:
          if METADATA_EMPTY in obj:
                 obj.hide_set(False)

          if METADATA_EMPTYLAND in obj:
              obj.hide_set(False)
              
          if METADATA_SPHERE in obj:
                 obj.hide_set(False)

        return {'FINISHED'}
    

class final_keyframe(bpy.types.Operator):
    """Set influence of location constraint on object to 1.0, so that object moves to empty."""

    bl_label = "Final Keyframe"
    bl_idname = "object.final_keyframe"
    def execute(self,context):
        scene = context.scene
       
        selected_objects = bpy.context.selected_objects
        if not selected_objects:
            self.report({'ERROR'}, 'Please select only the Empties')
            return {'CANCELLED'}
        
        if any(x for x in selected_objects if METADATA_EMPTY not in x) == True:
            self.report({'ERROR'},'Please select only the Empties')
            return {'CANCELLED'}

        drone_empty = {}
        for empty in selected_objects:
            if (METADATA_EMPTY in empty) and (empty["drone"] > 0):
                drone_empty[str(empty["drone"])+'S'] = empty
            elif  (METADATA_EMPTYLAND in empty) and (empty["drone"] > 0):
                drone_empty[str(empty["drone"])+'S'] = empty

        for obj in bpy.context.scene.objects:
            if METADATA_SPHERE in obj:
                empty = drone_empty.get(obj[METADATA_SPHERE])

                if empty is not None and empty.get("checkpoint") == 2:
                    obj.constraints["Copy Location"].influence = 1
                    obj.constraints["Copy Location"].keyframe_insert(data_path='influence')
                    obj.constraints["Copy Location"].name=str("copy done")
                    empty["checkpoint"]=3

        return {'FINISHED'}


