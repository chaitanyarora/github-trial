import bpy

class my_properties(bpy.types.PropertyGroup):
    Dist_Empty:bpy.props.FloatProperty(
       name="Dist_Empty",
       description="Dist_Empty",
       default=0,
    )
   
class empties(bpy.types.Panel):
    bl_label = "Empties "
    bl_idname = "BLENDER_PT_empties"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Formation'

    def draw(self, context):
        layout = self.layout
        scene=context.scene
        mytool = context.scene.my_tool.empties
        row = layout.row(align=True)
        row.prop(mytool,"Dist_Empty")   
        self.layout.operator('object.add_empties')
        self.layout.operator('object.vertices_without_empties')
        
class add_empties(bpy.types.Operator):
    bl_label = "Add All Empties"
    bl_idname = "object.add_empties"

    def execute(self,context):

        scene=context.scene
        mytool = context.scene.my_tool.empties
        obj=bpy.context.object

        distance=mytool.Dist_Empty
        if distance<0:
            self.report({'ERROR'},'Distance must be greater than or equal to zero')
            return {'CANCELLED'}
        
        selected_empties=[]

        # adding formation_id
        bpy.context.scene.formation_index =  bpy.context.scene.formation_index+1  

        # Create new collection to store empties for current formation
        new_coll =   bpy.data.collections.new(name="EMPTY_SET "+str(bpy.context.scene.formation_index))
        bpy.context.scene.collection.children.link(new_coll)

        coll = bpy.context.scene.collection

        # collecting vertex index
        selected_idx = [i.index for i in obj.data.vertices if i.select]
        if not selected_idx:
            bpy.data.collections.remove(new_coll, do_unlink=True)
            bpy.context.scene.formation_index =  bpy.context.scene.formation_index-1  
            self.report({'ERROR'},'Please select at least one vertex')
            return {'FINISHED'}
        world_coord_list = []
        for idx in selected_idx:
             point = obj.data.vertices[idx].co   # local
             world_coord = obj.matrix_world @ point   # get world coordinates

             world_coord_list.append(world_coord)    # append world coordinates in a list
        idx =0

        # get index of current formation 
        formation_index = str(bpy.context.scene.formation_index)

        '''
        iterate over each world coord data and add empties to the formation 
        if there is no vertex around them in desired distance
        '''
        for each_world_cord in world_coord_list:
             
             add_empties = True
             for each_selected_empty in selected_empties:
               if (each_selected_empty-each_world_cord).length < distance:
                add_empties=False
                break
             
             if(add_empties):  

                METADATA_EMPTY="md_empty"
                empty = bpy.data.objects.new('Empty', None)
                empty.name = f'{str(idx+1)}EM{formation_index}'

                # Store empty name in metadata 
                empty[METADATA_EMPTY]=f'{str(idx+1)}E{formation_index}'
                
                empty["drone"]=0
                empty["checkpoint"] = 0
                empty["vertex"] = 0

                # assign current world co ordinates in created empties
                empty.location = each_world_cord

                # link created obect empties to a new collumn 
                new_coll.objects.link(empty)                                    
                empty.empty_display_size = 1
                empty.empty_display_type = 'PLAIN_AXES'
                selected_empties.append(each_world_cord)
             idx+=1
            
        return {'FINISHED'}

class vertices_without_empties(bpy.types.Operator):

    bl_label = "Vertices without Empties"
    bl_idname = "object.vertices_without_empties"

    def execute(self,context):

        """
        Selects vertices in the active object's mesh that are not associated with any empties in the scene.
        """

        # Input validation
                
        selected_objects = bpy.context.selected_objects
        if not selected_objects or not any(obj.type == 'MESH' for obj in selected_objects):
            self.report({'ERROR'}, 'Please select a mesh')
            return {'CANCELLED'}

        if any(obj.type == 'EMPTY' for obj in selected_objects):
            self.report({'ERROR'}, 'Please select mesh only, Not empties')
            return {'CANCELLED'}
        
        selected_object = bpy.context.selected_objects[0]

        world_matrix = selected_object.matrix_world

        # Get the mesh data
        mesh = selected_object.data

        valid_world_coordinates = []

        # Loop through the vertices and check for empties
        for vertex in mesh.vertices:
            world_coord = world_matrix @ vertex.co
            empty_associated = False

            # Check for empties in the scene
            for empty in bpy.data.objects:
                if empty.type == 'EMPTY' and (empty.location - world_coord).length < 0.001:
                    empty_associated = True
                    break  # Exit the loop if an empty is found

            if not empty_associated:
                valid_world_coordinates.append(world_coord)

        # Deselect all vertices in the mesh
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')

        # Update the mesh's selection
        bpy.context.object.data.update()

        # Select the closest vertex to each valid world coordinate
        for world_coord in valid_world_coordinates:
            local_coord = world_matrix.inverted() @ world_coord
            closest_vertex = min(mesh.vertices, key=lambda v: (v.co - local_coord).length)
            closest_vertex.select = True

        # Switch to Edit Mode to see the selected vertices
        bpy.ops.object.mode_set(mode='EDIT')

        return {'FINISHED'}
