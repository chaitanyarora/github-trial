import bpy


# Define a custom property name for storing object names as metadata
METADATA_SPHERE = "md_sphere"


class my_properties(bpy.types.PropertyGroup):
    lower: bpy.props.IntProperty(
       name=" Lower ",
       description="lower ",
       default=0,
    )
   
    upper: bpy.props.IntProperty(
       name="Upper",
       description="Upper ",
       default=0,
    )
   
    distance: bpy.props.FloatProperty(
       name="Distance",
       description=" distance threshold in meters ",
       default=0,
    )
    
    starting_frame: bpy.props.IntProperty(
       name="Starting Frame",
       description=" starting frame",
       default=0,
    )
   
    scene_frames: bpy.props.IntProperty(
       name=" End Frames",
       description=" length of animation in frames ",
       default=0,
    )
   
   
class collision_setup(bpy.types.Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "Collision"
    bl_idname = "OBJECT_PT_collision"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Output"

    def draw(self, context):
        layout = self.layout
 
        sce = context.scene
        mytool = sce.my_tool.collision

        row = layout.row(align=True)
        row.prop(mytool, "lower")

        row = layout.row(align=True)
        row.prop(mytool, "upper")
       
        row = layout.row(align=True)
        row.prop(mytool, "distance")
        
        row = layout.row(align=True)
        row.prop(mytool, "starting_frame")
       
        row = layout.row(align=True)
        row.prop(mytool, "scene_frames")
       
       
        row = layout.row()
        row.operator("object.my_collision")

   
# Define a new operator class
class apply_collision(bpy.types.Operator):
    # The ID name of the operator (must be unique)
    bl_idname = "object.my_collision"
    # The display name of the operator
    bl_label = "Apply_Collision"

    # The main execution function of the operator
    def execute(self, context):
        sce = context.scene
        mytool = sce.my_tool.collision
                
        lower=mytool.lower
        upper=mytool.upper

        #============================Parameter====================================
        distance = mytool.distance # distance threshold in meters 
        starting_frame=mytool.starting_frame

        scene_frames =mytool.scene_frames # length of animation in frames
        #=========================================================================

        bpy.ops.object.select_all(action='DESELECT')

        prefetch = {}
         # to prefetch the sphere 
        for collection in bpy.data.collections:
            if collection.name in ["SPHERE", "CONCEPT"]:
                for obj in collection.objects:  
                    if lower < int(obj.get(METADATA_SPHERE).split('S')[0]) <= upper:
                        prefetch[obj.get(METADATA_SPHERE)] = obj
                        obj.select_set(True)

        if (lower)<0:
            self.report({'ERROR'},'Lower should be greater than 0')
            return {'CANCELLED'}
        
        if (upper - lower < 1):
            self.report({'ERROR'},'Value of Upper should be atleast 1 greater than lower')
            return {'CANCELLED'}
        
        if (scene_frames - starting_frame < 1):
            self.report({'ERROR'},'Value of end_frames should be atleast 1 greater than starting_frame')
            return {'CANCELLED'}
        
        # Get the collection by name
        len_spheres = bpy.data.collections.get('SPHERE')
        len_concept = bpy.data.collections.get('CONCEPT')

        if len_spheres:
            if (upper) > len(len_spheres.objects):
                self.report({'ERROR'},'Value of Upper should not be greater than the no. of Spheres')
                return {'CANCELLED'}

        if distance<0:
            self.report({'ERROR'},'distance should be greater than 0')
            return {'CANCELLED'}
        
        if len_concept:
            if (upper) > len(len_concept.objects):
                self.report({'ERROR'},'Value of Upper should not be greater than the no. of Spheres')
                return {'CANCELLED'}

        d_threshold = distance*100 # distance threshold in meters
         
        # CHANGE SCALE BASED ON SCRIPT OUTPUT TO INREASE OR DECREASE DISTANCE
        scale = 1
        
  

        global dict_store
        dict_store={}

        def add_to_dict(drone_id,pos):
            """add_to_dict adds the position pos of the drone with drone_id in the dictionary dict_store
            """
            global dict_store
            # checks whether the grouping where x-coordinate of pos will lie in is already there in the dictionary
            # if not there already, insert it as an key with empty dictionary as the value
            if pos[0]//2*2 not in dict_store:
                dict_store[int(pos[0]//2*2)]={}
            # checks whether the grouping where y-coordinate of pos will lie in is already there in the dictionary
            # if not there already, insert it as an key with empty dictionary as the value
            if pos[1]//2*2 not in dict_store[pos[0]//2*2]:
                dict_store[int(pos[0]//2*2)][int(pos[1]//2*2)]={}
            # checks whether the grouping where z-coordinate of pos will lie in is already there in the dictionary
            # if not there already, insert it as an key with empty dictionary as the value
            if pos[2]//2*2 not in dict_store[pos[0]//2*2][pos[1]//2*2]:
                dict_store[int(pos[0]//2*2)][int(pos[1]//2*2)][int(pos[2]//2*2)]={}
            # insert the drone having drone_id at the respective grouping of x, y and z coordinates and give its value as the position 
            dict_store[int(pos[0]//2*2)][int(pos[1]//2*2)][int(pos[2]//2*2)][drone_id]=pos


        def nearby_in_dict(drone_id,pos,dict_store):
            """find the drones which have possibility of being in the region of influence of the drone with drone_id and at position pos
            """
            nearby=[]
            # loop over the possible x-coordinate values for the nearby drones
            for x in range(int((pos[0]-d_threshold)//2*2),int((pos[0]+d_threshold)//2*2)+1,2):
                if x not in dict_store:
                    continue
                # loop over the possible y-coordinate values for the nearby drones
                for y in range(int((pos[1]-d_threshold)//2*2),int((pos[1]+d_threshold)//2*2)+1,2):
                    if y not in dict_store[x]:
                        continue
                    # loop over the possible z-coordinate values for the nearby drones
                    for z in range(int((pos[2]-d_threshold)//2*2),int((pos[2]+d_threshold)//2*2)+1,2):
                        if z not in dict_store[x][y]:
                            continue
                        # found a possible drone
                        for drone in dict_store[x][y][z]:
                            # check whether the drone we have found is itself the drone for which nearby neighbours need to be found
                            if drone<=drone_id:
                                continue
                            else:
                                dist=((dict_store[x][y][z][drone][0]-pos[0])**2+(dict_store[x][y][z][drone][1]-pos[1])**2+ \
                                    (dict_store[x][y][z][drone][2]-pos[2])**2)**0.5
                                if dist<d_threshold:
                                    nearby.append((dict_store[x][y][z][drone],drone,dist))
            return nearby

        print("\nRunning distance check\n")
        d={}
        store_pos={}
        for f in range(starting_frame, scene_frames):
            dict_store={}
            if ((f-1) % 12 == 0):
                sce.frame_set(f)
                store_pos[f]={}
                for i in range(lower,upper):
                    obj = f"{i + 1}S"
                    ob = prefetch.get(obj) 
                    x = int(ob.matrix_world.to_translation().x*100 * scale)
                    y = int(ob.matrix_world.to_translation().y*100 * scale)
                    z = int(ob.matrix_world.to_translation().z*100 * scale)
                    add_to_dict(i+1,(x,y,z))
                    store_pos[f][i+1]=(x,y,z)
                d[f]=dict_store
                

        for i in range(lower,upper):
            print("\nChecking Drone " + str(i+1))
            collisions={}
            for f in range(starting_frame, scene_frames):
                if ((f-1) % 12 == 0):
                    nearby = nearby_in_dict(i+1,store_pos[f][i+1],d[f])
                    for j in range(len(nearby)):
                        if nearby[j][1] not in collisions:
                            collisions[nearby[j][1]]=[]    
                        collisions[nearby[j][1]].append((round(nearby[j][2]/100,2),f))
            for j in sorted(collisions):
                for k in range(len(collisions[j])):
                    print("1- Danger! Distance = " + str(collisions[j][k][0]) + " m between " + str(i+1) + " and " + str(j) + " on frame " + str(collisions[j][k][1]))
               
        print("\nDone checking distance")       
               
        return {'FINISHED'}
    


