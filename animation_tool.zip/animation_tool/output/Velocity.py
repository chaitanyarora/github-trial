import bpy
import time
from itertools import chain

# Define a custom property name for storing object names as metadata
METADATA_SPHERE = "md_sphere"

class my_properties(bpy.types.PropertyGroup):
    lower: bpy.props.IntProperty(
       name=" Lower ",
       description="Lower ",
       default=0,
    )
   
    upper: bpy.props.IntProperty(
       name="Upper",
       description="Upper ",
       default=0,
    )
   
    speed_threshold : bpy.props.FloatProperty(
       name="Speed Threshold ",
       description=" distance threshold in meters ",
       default=0.0,
    )

    starting_frame: bpy.props.IntProperty(
       name="Starting Frame",
       description=" starting frame",
       default=0,
    )
   
    end_frames: bpy.props.IntProperty(
       name=" End Frames",
       description=" length of animation in frames ",
       default=0,
    )
   
   
class velocity_setup(bpy.types.Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "Velocity"
    bl_idname = "BLENDER_PT_velocity_setup1"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Output"

    def draw(self, context):
        layout = self.layout
 
        scene = context.scene
        mytool = scene.my_tool.velocity

        row = layout.row(align=True)
        row.prop(mytool, "lower")

        row = layout.row(align=True)
        row.prop(mytool, "upper")
       
        row = layout.row(align=True)
        row.prop(mytool, "speed_threshold")
       
        row = layout.row(align=True)
        row.prop(mytool, "starting_frame")
       
        row = layout.row(align=True)
        row.prop(mytool, "end_frames")
        
        row = layout.row()
        row.operator("object.my_velocity")


class apply_velocity(bpy.types.Operator):
    bl_idname = "object.my_velocity"
    bl_label = "Apply Velocity"

    def execute(self, context):
        scene = context.scene
        my_tool = scene.my_tool.velocity

        frame_rate = 24
        drone_positions = {}

        lower, upper = my_tool.lower, my_tool.upper
        start_frame, end_frames = my_tool.starting_frame, my_tool.end_frames
        speed_threshold = my_tool.speed_threshold

        if (lower)<0:
            self.report({'ERROR'},'Lower should be greater than 0')
            return {'CANCELLED'}
        
        if (upper - lower < 1):
            self.report({'ERROR'},'Value of Upper should be atleast 1 greater than lower')
            return {'CANCELLED'}
        
        if (end_frames - start_frame < 1):
            self.report({'ERROR'},'Value of end_frames should be atleast 1 greater than starting_frame')
            return {'CANCELLED'}
        
        # Get the collection by name
        len_spheres = bpy.data.collections.get('SPHERE')
        len_concept = bpy.data.collections.get('CONCEPT')

        if len_spheres:
            if (upper) > len(len_spheres.objects):
                self.report({'ERROR'},'Value of Upper should not be greater than the no. of Spheres')
                return {'CANCELLED'}
        
        if len_concept:
            if (upper) > len(len_concept.objects):
                self.report({'ERROR'},'Value of Upper should not be greater than the no. of Spheres')
                return {'CANCELLED'}

        if speed_threshold<0:
            self.report({'ERROR'},'Speed should be greater than 0')
            return {'CANCELLED'}

        print("\nRunning velocity check")

        start_time = time.time()

        scene.frame_set(start_frame)

        for i in range(lower, upper):
            ob = f"{i + 1}S"
            # Iterate through all collections in the scene
            for collection in bpy.data.collections:
                # Check if the name of the collection matches the desired name
                if collection.name in ("SPHERE", "CONCEPT"):
                    # Access the objects in the matched collection
                    for obj in collection.objects:
                        if ob == obj.get(METADATA_SPHERE):
                            ob = obj
                            break  # Stop searching once drone is found

            if ob:
                drone_positions[i + 1] = ob.matrix_world.translation.copy()

        dangerous_speed = [[] for _ in range(upper - lower)] 

        for frame in range(start_frame+1, end_frames + 1):
            scene.frame_set(frame)

            for i in range(lower, upper):
                ob = f"{i + 1}S"
                # Iterate through all collections in the scene
                for collection in bpy.data.collections:
                    # Check if the name of the collection matches the desired name
                    if collection.name in ("SPHERE", "CONCEPT"):
                        # Access the objects in the matched collection
                        for obj in collection.objects:
                            if ob == obj.get(METADATA_SPHERE):
                                ob = obj
                                break  # Stop searching once drone is found

                if ob:
                    position = ob.matrix_world.translation.copy()

                    # Calculate speed based on the change in position
                    distance = (position - drone_positions[i + 1]).length
                    speed = distance / (1/frame_rate)

                    if position.length > 0 and speed > speed_threshold:
                        # Store the dangerous speed information
                        dangerous_speed[i].append((i + 1, frame, speed))

                    # Update the previous position for the drone
                    drone_positions[i + 1] = position
        
        dangerous_speed = list(chain(*dangerous_speed))
        current_drone = None
        for info in dangerous_speed:
            drone_number = info[0]
            if drone_number != current_drone:
                print(f"\n----------------------- Drone {drone_number} -----------------------\n")
                current_drone = drone_number
            print(f"Danger! Speed = {info[2]:.2f} m/s for {info[0]} drone on frame {info[1]}")

        print("\nDone checking velocity")

        end_time = time.time()
        execution_time = end_time - start_time
        print(f"Execution time for velocity: {execution_time} seconds")

        return {'FINISHED'}
    