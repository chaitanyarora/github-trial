import bpy
import os
import time

# Define a custom property name for storing object names as metadata
METADATA_SPHERE = "md_sphere"

class my_properties(bpy.types.PropertyGroup):
    
    upper_id: bpy.props.IntProperty(
       name="Upper",
       description="To set upper drone id.",
       default=1,
    )
    
    lower_id: bpy.props.IntProperty(
       name="Lower",
       description="To set lower drone id.",
       default=0,
    )
    
    folder_path: bpy.props.StringProperty(name=" PATH",
                                        description="Some elaborate description",
                                        default="",
                                        subtype="DIR_PATH"
    )
    
    no_of_frame_scene: bpy.props.IntProperty(
       name="Frame Scene",
       description="To set numbner of frame scenes.",
       default=0,
    )


class extraction_setup(bpy.types.Panel):
    bl_label = "Extraction"
    bl_idname = "BLENDER_PT_extraction_setup"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Output'

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool.extraction

        row = layout.row(align=True)
        row.prop(mytool, "lower_id")
        row = layout.row(align=True)
        row.prop(mytool,"upper_id")
        
        row = layout.row(align=True)
        row.prop(mytool,"no_of_frame_scene")

        row = layout.row(align=True)
        row.prop(mytool,"folder_path")

        row = layout.row(align=True)
        layout.operator("text.run")


class extract_file(bpy.types.Operator):
    """To start code of optimized extraction file"""

    bl_label = "Extract"
    bl_idname = "text.run"
    
    def execute(self,context):
        start_time1 = time.time()
        scene = context.scene
        mytool = scene.my_tool.extraction
        
        Upper = mytool.upper_id
        Lower = mytool.lower_id
        Path = mytool.folder_path
        scene_frames = mytool.no_of_frame_scene


        bpy.ops.object.select_all(action='DESELECT')
        prefetch = {}
         # to prefetch the sphere 
        for collection in bpy.data.collections:
            if collection.name in ["SPHERE", "CONCEPT"]:
                for obj in collection.objects:  
                    if Lower < int(obj.get(METADATA_SPHERE).split('S')[0]) <= Upper:
                        prefetch[obj.get(METADATA_SPHERE)] = obj
                        obj.select_set(True)
       
        if Lower<0:
            self.report({'ERROR'},'Lower should be greater than 0')
            return {'CANCELLED'}

        if (Upper - Lower < 1):
            self.report({'ERROR'},'Value of Upper should be atleast 1 greater than lower')
            return {'CANCELLED'}
        
        # Get the collection by name
        len_spheres = bpy.data.collections.get('SPHERE')
        len_concept = bpy.data.collections.get('CONCEPT')
               
        if len_spheres:
            if Upper > len(len_spheres.objects) :
                self.report({'ERROR'},'Value of Upper should not be greater than the no. of Spheres')
                return {'CANCELLED'}
            
        if len_concept:
            if Upper > len(len_concept.objects):
                self.report({'ERROR'},'Value of Upper should not be greater than the no. of Spheres')
                return {'CANCELLED'}
            
        #target autopilot framerate, default value is 4 
        frame_rate = 25  
        #for color extraction
        gamma = 1
        #For extracting time_frame 
        index=0
        
        current_path = os.getcwd()
        Path = bpy.path.abspath(Path)

        if not Path:
            if not os.path.exists(current_path+'/Extraction'):
                os.mkdir("Extraction")
            Path = current_path+'/Extraction'
            
        sce = bpy.context.scene

        # Open files for writing before the frame loop
        files = {}
        counter = 0
        for i in range(Lower, Upper):
            file_path = Path + '/drone-' + str(i + 1) + '.csv'
            files[i] = open(file_path, 'w')

        for f in range(sce.frame_start - 1, scene_frames):
            sce.frame_set(f)
            for i in range(Lower, Upper):  
                name = f'{i+1}S'
                obj = prefetch.get(name)
                mat = obj.data.materials[0] 
                X, Y, Z = obj.matrix_world.translation
                COL = mat.diffuse_color

                r = int(round(255 * pow(COL[0] * 255 / 255, gamma), 0))
                g = int(round(255 * pow(COL[1] * 255 / 255, gamma), 0))
                b = int(round(255 * pow(COL[2] * 255 / 255, gamma), 0))

                file = files[i]
    
                file.write(f"{int(index / frame_rate)}\t{round(X, 2)}\t{round(Y, 2)}\t{round(Z, 2)}\t{r}\t{g}\t{b}\n")

                counter += 1
                # Calculate the percentage completed directly
                percentage_completed = (counter / (scene_frames - sce.frame_start + 1) / (Upper - Lower)) * 100
                
                # Print the percentage completed
                print(f"Percentage Completed: {percentage_completed:.2f}%", end='\r')

            index += 1
                
        # Close files after the frame loop
        for file in files.values():
            file.close()
        end_time1 = time.time()
        execution_time1 = end_time1 - start_time1

        print(f"Execution time for Extraction: {execution_time1} seconds")

        print("\nFile Extracted Successfully!")

        return {'FINISHED'}

                
                
                
        
    





