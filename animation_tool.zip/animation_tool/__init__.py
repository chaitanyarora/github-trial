import bpy
from  animation_tool.formation import Drone,Empties,Trajectory,Follow_path,Concept
from  animation_tool.color import Palette,Solid_color,Effect,Color_Transfer
from  animation_tool.output import Extract,Collision,Velocity
from  animation_tool.landing import APF,Dis_influence,Bucket_PD


bl_info = {
    "name": "Metadata Beta 1.5.2",
    "author": "Botlab Dynamics",
    "version": (1, 5, 2),
    "blender": (4, 1, 1),
    "location": "View3D > Sidebar > Create Tab",
    "description": "",
    "warning": "",
    "doc_url": "",
    "category": "Drone light show toolbox",
}


classes=[
            Drone.reset_scene, 
            Drone.sphere_grid,
            Drone.my_properties,
            Drone.drone_setup,
            Empties.add_empties,
            Empties.vertices_without_empties,
            Empties.my_properties, 
            Empties.empties, 
            Trajectory.assign_vertex_group_to_empties,
            Trajectory.collision_avoidance,
            Trajectory.unhidden,
            Trajectory.initial_keyframe,
            Trajectory.final_keyframe,
            Trajectory.formation_trajectory,
            Follow_path.follow_path_keyframe,
            Follow_path.follow_path_offset,
            Follow_path.follow_path_select_mesh,
            Follow_path.follow_path_setup,
            Follow_path.my_properties,
            Follow_path.add_single_empty,
            Concept.add_concept,
            Concept.delete_concept,
            Concept.concept_setup,
            Effect.my_properties,
            Effect.effector_setup,
            Effect.color_Effector,
            Solid_color.actual_color_setup,
            Solid_color.color_keyframe,
            Solid_color.color_drone,
            Solid_color.active_node,
            Solid_color.unactive_node,
            Solid_color.my_properties,
            Palette.palette,
            Palette.my_properties,
            Palette.palette_setup,
            Palette.color_drone_palette,
            Palette.disable_palette,
            Color_Transfer.my_properties,
            Color_Transfer.color_Transfer,
            Color_Transfer.Import,
            Color_Transfer.Export,
            Extract.my_properties,
            Extract.extraction_setup,
            Extract.extract_file,
            Dis_influence.dis_influence_setup,
            Dis_influence.dis_influence,
            APF.my_properties,
            APF.drone_landing_apf_setup,
            APF.drone_landing_apf,
            # PD.my_properties,
            # PD.priority_delay_panel,
            # PD.priority_delay_algorthm,
            Collision.my_properties,
            Collision.collision_setup,
            Collision.apply_collision,
            Velocity.my_properties,
            Velocity.velocity_setup,
            Velocity.apply_velocity,
            Bucket_PD.my_properties,
            Bucket_PD.bucket_priority_delay_panel,
            Bucket_PD.bucket_priority_delay_algorthim,
        ]


class properties(bpy.types.PropertyGroup):
    drone: bpy.props.PointerProperty(type=Drone.my_properties)
    empties: bpy.props.PointerProperty(type=Empties.my_properties)
    follow_path: bpy.props.PointerProperty(type=Follow_path.my_properties)
    effector: bpy.props.PointerProperty(type=Effect.my_properties)
    solid_color: bpy.props.PointerProperty(type= Solid_color.my_properties)
    palette : bpy.props.CollectionProperty(type=Palette.my_properties)
    color_transfer:bpy.props.PointerProperty(type= Color_Transfer.my_properties)
    extraction: bpy.props.PointerProperty(type= Extract.my_properties)
    collision: bpy.props.PointerProperty(type= Collision.my_properties)
    velocity: bpy.props.PointerProperty(type= Velocity.my_properties)
    apf: bpy.props.PointerProperty(type= APF.my_properties)
    # pd: bpy.props.PointerProperty(type= PD.my_properties)
    bucket_pd: bpy.props.PointerProperty(type= Bucket_PD.my_properties)
   
    
def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.utils.register_class(properties)

    # intialise global variable
    bpy.types.Scene.my_tool=bpy.props.PointerProperty(type = properties)
    bpy.types.Scene.formation_index = bpy.props.IntProperty(default=0)
    bpy.types.Scene.node_shader_thread = bpy.props.IntProperty(default=0)
    bpy.types.Scene.create_custom_layout = bpy.props.BoolProperty(name="layout switching",default=True)
   
    
def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    bpy.utils.unregister_class(properties) 

"""  Delete variable """
 # del bpy.types.Scene.my_tool

if __name__ == "__main__":
    register()
   
