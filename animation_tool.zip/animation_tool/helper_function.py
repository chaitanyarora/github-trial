import numpy as np
from scipy.optimize import linear_sum_assignment
import mathutils
from mathutils import Vector


# only used in PD landing
def delete(vec, vec2):
    temp = []
    for x, i in enumerate(vec):
        temp.append(i / vec2[x])
    return mathutils.Vector(temp)

def coor_xyz(obj):
    """Return the xyz coordinates of the object."""
    obj_x=list(obj.matrix_world[0])[3]
    obj_y=list(obj.matrix_world[1])[3]
    obj_z=list(obj.matrix_world[2])[3]
    return [obj_x,obj_y,obj_z]

def assign_hungarian(start, goal):
    """Find an assignment between start and goal positions using Hungarian algorithm."""

    size = (len(start), len(goal))
    cost_matrix = np.zeros(size)

    for i in range(size[0]):
        for j in range(size[1]):
            cost_matrix[i][j] = sum((start[i][k] - goal[j][k])**2 for k in range(len(start[0])))

    rows, cols = linear_sum_assignment(cost_matrix)
    return list(zip(rows, cols))



