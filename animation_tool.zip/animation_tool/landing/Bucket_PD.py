import bpy
import math
import time


class my_properties(bpy.types.PropertyGroup):
    drone_speed: bpy.props.FloatProperty(
       name="Speed (m/sec)",
       description="Speed of the Drone in m/sec",
       default=2.5,
    )
   
    total_drones: bpy.props.IntProperty(
       name="Total drones",
       description="Total number of Drones",
       default=0,
    )
   
    start_frame: bpy.props.IntProperty(
       name="Start frame",
       description="Starting frame",
       default=0,
    )

    stopping_frame: bpy.props.IntProperty(
       name="Last frame",
       description="Stopping frame",
       default=0,
    )

    distance: bpy.props.FloatProperty(
       name="Drone collision (m)",
       description="threshold for collision avoidance",
       default=2.5,
    )
   
    time_delay: bpy.props.FloatProperty(
       name="delay",
       description="delay in landing for collison avoidance",
       default=0.4,
    )
   
   

   
class bucket_priority_delay_panel(bpy.types.Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "Bucket_PD Landing"
    bl_idname = "BLENDER_PT_bucket_priority_delay_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Landing"

    def draw(self, context):
        layout = self.layout
 
        scene = context.scene
        mytool = scene.my_tool.bucket_pd

        row = layout.row(align=True)
        row.prop(mytool, "drone_speed")

        row = layout.row(align=True)
        row.prop(mytool, "total_drones")
       
        row = layout.row(align=True)
        row.prop(mytool, "start_frame")
       
        row = layout.row(align=True)
        row.prop(mytool, "stopping_frame")
       
        row = layout.row(align=True)
        row.prop(mytool, "distance")
       
        row = layout.row(align=True)
        row.prop(mytool, "time_delay")
              
        row = layout.row()
        row.operator("object.bucket_priority_delay_algorthim")

   
# Define a new operator class
class bucket_priority_delay_algorthim(bpy.types.Operator):
    # The ID name of the operator (must be unique)
    bl_idname = "object.bucket_priority_delay_algorthim"
    # The display name of the operator
    bl_label = "Waterfall"

    # The main execution function of the operator
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool.bucket_pd

        # Input validation

        if (mytool.drone_speed<=0):
            self.report({'ERROR'},'Drone speed must be greater than 0')
            return {'CANCELLED'}
        
        # Get the collection by name
        len_spheres = bpy.data.collections.get('SPHERE ')
        len_concept = bpy.data.collections.get('CONCEPT')
        
        if (mytool.total_drones) > (len(len_spheres.objects) or len(len_concept.objects)):
            self.report({'ERROR'},'Total drones should not be greater than the no. of Spheres')
            return {'CANCELLED'}
        
        if (mytool.stopping_frame - mytool.start_frame < 1):
            self.report({'ERROR'},'Value of last frame should be atleast 1 greater than start frame')
            return {'CANCELLED'}
        
        if (mytool.distance<=0):
            self.report({'ERROR'},'Drone collision must be greater than 0')
            return {'CANCELLED'}
        
        if (mytool.time_delay<=0):
            self.report({'ERROR'},'Delay must be greater than 0')
            return {'CANCELLED'}


        # Store the initial landing positions of the drones in a dictionary
        # Set the start and end frames of the animation

        stop_frame_period=(mytool.time_delay)*24
            
        land_frame=[0]*mytool.total_drones
        final_target=[0]*mytool.total_drones

    
        stop_semaphore=[0]*mytool.total_drones
        stop_frame=[0]*mytool.total_drones
        ignore_stop_frame=[0]*mytool.total_drones

        reached_flag=[0]*mytool.total_drones
        landing = {i: (1000, 0) for i in range(1, mytool.total_drones+1)}
        # print(landing)
        
    
        # play the animation
        for frame in range(mytool.start_frame, mytool.stopping_frame + 1,12):           
            # Set the current frame
            bpy.context.scene.frame_set(frame)
            for drone in bpy.context.scene.objects:
                if (drone.name[-1] == 'S' and landing.get(int(drone.name[:-1]))[0] > 0):
                    #print(drone.name, frame)
                   
                    # Get the current position of the drone
                    a = (bpy.context.scene.objects[drone.name].matrix_world[0][3],bpy.context.scene.objects[drone.name].matrix_world[1][3],bpy.context.scene.objects[drone.name].matrix_world[2][3])
                    b1 = str(drone.name[:-1] + 'E0')
                    b2 = bpy.context.scene.objects[b1]
                   
                    # Get the target position of the drone
                    b = (b2.location[0],b2.location[1],b2.location[2])
                   
                    # Calculate the distance between the current and target positions
                    d = math.dist(a, b)
                   
                    # Check if the drone has reached its target
                    if (d > landing.get(int(drone.name[:-1]))[0]):  
                        # print(f'Land {drone.name} drone at {frame} frame')
                       
                        # Update the landing dictionary with the new position and frame
                        landing[int(drone.name[:-1])] = (0, frame)
                       
                        # code for disinfluence
                        X = bpy.context.scene.objects[drone.name].matrix_world[0][3]
                        Y = bpy.context.scene.objects[drone.name].matrix_world[1][3]
                        Z = bpy.context.scene.objects[drone.name].matrix_world[2][3]
                       
                        bpy.context.scene.objects[drone.name].location.x = X
                        bpy.context.scene.objects[drone.name].location.y = Y
                        bpy.context.scene.objects[drone.name].location.z = Z
                        bpy.context.scene.objects[drone.name].keyframe_insert(data_path="location", frame=frame-1)
                        
                        
                        constraint=list(bpy.context.scene.objects[drone.name].constraints)
                        for x in constraint:
                            x.keyframe_insert(data_path='influence',frame=frame)

                        for x in constraint:
                            x.influence=0
                            x.keyframe_insert (data_path='influence',frame=frame+1)
                       

                        old_z=Z
                        new_z=Z-20
                        bpy.context.scene.objects[drone.name].location.z=new_z
                        time=(old_z-new_z)/(mytool.drone_speed)
                        f=24*time
                        drone.keyframe_insert(data_path="location", frame=frame+f)
                        
                        #Go to intial point
                        a=drone.name[:-1]
                        ignore_stop_frame[int(a)-1]=frame+f
                        for obj2 in bpy.context.scene.objects:
                            intial_name=obj2.name
                            if "E" in intial_name :
                                intial_target=intial_name[-2: ]
                                if("E0" == intial_target):    
                                 c=intial_name[:-2]
                                 if(a==c):
                                      drone.location.x = obj2.location.x
                                      drone.location.y = obj2.location.y
                                      drone.location.z = obj2.location.z+5
                                     
                                      # add frame to maintain required speed
                                      old_z=new_z
                                      new_z=obj2.location.z+5
                                      
                                      current_x=X
                                      current_y=Y
                                      current_height=Z-20
                                      target_x=obj2.location.x
                                      target_y=obj2.location.y
                                      target_height=obj2.location.z+5
                                      distance=((current_x-target_x)**2+(current_y-target_y)**2+(current_height-target_height)**2)**(1/2)
                                      
                                      time=distance/mytool.drone_speed
                                      f_delay=24*time
                                      drone.keyframe_insert(data_path="location", frame=frame+f+f_delay)
                                     
                                      #   drone.location.z = obj2.location.z
                                      #   old_z=new_z
                                      #   new_z=drone.location.z
                                      #   time=(old_z-new_z)/mytool.drone_speed
                                      #   f_f=24*time
                                      #  drone.keyframe_insert(data_path="location", frame=frame+f+f_+f_f)  
                                      
                                      land_frame[int(drone.name[:-1])-1]=frame+f+f_delay
                                      final_target[int(drone.name[:-1])-1]=obj2

                    else:
                        # Update the landing dictionary with the current position and previous frame
                        landing[int(drone.name[:-1])] = (d, landing[int(drone.name[:-1])][1])
                       
        # print(land_frame)
       
   
        # ####################################################################################################
        # #collision_avoidance in column side
        sce = bpy.context.scene
        d_threshold = mytool.distance*100# distance threshold in meters
        scale = 1
        print("\nRunning distance check\n")

        starting_frame=mytool.start_frame

        drone=[]
        for i in range(1, mytool.total_drones+1):
            drone.append(str(i)+"S")

      
        f=starting_frame
        reached=min(reached_flag)
        while(reached==0):
            if((f-1) % 4 == 0):
                  sce.frame_set(f)
                  for i in range(len(drone)):
                    # scanning all drones one by one  
                    ob = bpy.data.objects[drone[i]]
                    #print("\n Checking Sphere " + drone[i])
                    x = int(ob.matrix_world.to_translation().x * scale)
                    y = int(ob.matrix_world.to_translation().y * scale)
                    z = int(ob.matrix_world.to_translation().z * scale)
                   
                    lower = 1
                    upper = mytool.total_drones

                    empty=final_target[int(ob.name[:-1])-1]   
                    target_x=empty.location.x
                    target_y=empty.location.y
                    target_height=empty.location.z+5

                    if(f<=ignore_stop_frame[int(ob.name[:-1])-1]):
                        continue
                    
                    # reached                       
                    if(abs(z-empty.location.z-5)==0):
                                ob.location.z = empty.location.z      
                                land_frame[i]= land_frame[i]+((5/mytool.drone_speed)*24)              
                                ob.keyframe_insert(data_path="location", frame=land_frame[i])
                                reached_flag[i]=1 
                    
                    
                    x=x*100
                    y=y*100
                    z=z*100
                    # waiting to avoid collision
                    if(stop_semaphore[i]==1):
                        if(f >= stop_frame[i]):
                            stop_semaphore[i]=0
                           
                            
                    if(reached_flag[i]==0 and  stop_semaphore[i]==0):
                         for k in range(lower-1,upper):
                          if(i!=k):    
                            #Comparing the selected drone of outer loop with respect to its row drones only        
                            ob2 = bpy.data.objects[drone[k]]
                            x2 = int(ob2.matrix_world.to_translation().x*100 * scale)
                            y2 = int(ob2.matrix_world.to_translation().y*100 * scale)
                            z2 = int(ob2.matrix_world.to_translation().z*100 * scale)
                            dx = x2 - x
                            dy = y2 - y
                            dz = z2 - z
                            d = math.sqrt(dx*dx + dy*dy + dz*dz)  
                            if(d < d_threshold):
                                if(((z>z2) or (z==z2 and i<k))):
                                    if(reached_flag[k]==0):    
                                    #    print(drone[i]+"||"+drone[k]+"||"+str(round(d/100,2))+"||"+str(f)+"||"+'\n')
                                       stop_semaphore[i]=1
                                    
                                       ob.keyframe_insert(data_path="location", frame=f)
                                       ob.keyframe_insert(data_path="location", frame=f+stop_frame_period)
                                       stop_frame[i]=f+stop_frame_period

                                      
                                       ob.keyframe_delete(data_path="location", frame=land_frame[i])
                                       
                                       current_height= z/100
                                       current_x=x/100
                                       current_y=y/100
                                       ob.location.x = target_x
                                       ob.location.y = target_y
                                       ob.location.z = target_height # offset of 5
                                
                                       distance=((current_x-target_x)**2+(current_y-target_y)**2+(current_height-target_height)**2)**(1/2)
                                       time=distance/mytool.drone_speed
                                       f1_delay=24*time
                                       land_frame[i]= f+stop_frame_period+f1_delay 
                                       ob.keyframe_insert(data_path="location", frame=land_frame[i])
                                       break

                                       
            f=f+1  
            reached=min(reached_flag)
            # print("frame_tested="+str(f))
        print("\nlanding applied")
        return {'FINISHED'}