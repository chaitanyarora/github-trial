import bpy
import time

# Define a custom property name for storing object names as metadata
METADATA_SPHERE = "md_sphere"

class dis_influence_setup(bpy.types.Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "Disinfluence"
    bl_idname = "OBJECT_PT_dis_influence_setup"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Landing"

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.operator("object.assemble_drone")
        
        
class dis_influence(bpy.types.Operator):
    bl_label = "Disinfluence"
    bl_idname = "object.assemble_drone"
    
    def execute(self,context):
        scene = context.scene

        start_time = time.time()
        selected_objects = bpy.context.selected_objects

        if any(x for x in selected_objects if METADATA_SPHERE not in x) == True:
            self.report({'ERROR'},'Please select sphere only')
            return {'CANCELLED'}

        if not selected_objects:
            self.report({'ERROR'},'Please select atleast one sphere')
            return {'CANCELLED'}

        frame_current = bpy.data.scenes['Scene'].frame_current

        for obj in selected_objects:
            if METADATA_SPHERE not in obj:
                continue

            matrix_world = obj.matrix_world
            translation = matrix_world.translation
            obj.location = translation
            obj.keyframe_insert(data_path="location", frame=frame_current - 1)

            for constraint in obj.constraints:
                constraint.keyframe_insert(data_path='influence', frame=frame_current)
                constraint.influence = 0
                constraint.keyframe_insert(data_path='influence', frame=frame_current + 1)

        end_time = time.time()
        execution_time = end_time - start_time
        print(f"\nExecution time for disinfluence: {execution_time} seconds")

        return {'FINISHED'}
