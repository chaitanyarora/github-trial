import bpy
import random
import numpy as np

# Define a custom property name for storing object names as metadata
METADATA_SPHERE = "md_sphere"
METADATA_EMPTYLAND = "md_emptyland"

    
class my_properties(bpy.types.PropertyGroup):

    height_for_end_position_: bpy.props.FloatProperty(
       name="Height for end position",
       description="height of the drones till where landing algo needs to do the landing",
       default=10,
    )

    height_for_descend_: bpy.props.FloatProperty(
       name="Height for descend",
       description="height of the drones from where the drones have to descend",
       default=30,
    )

    height_for_scaled_grid_: bpy.props.FloatProperty(
       name="Height for scaled grid",
       description="height of the scaled grid",
       default=40,
    )

    drone_sep_while_landing: bpy.props.FloatProperty(
       name="Drone sep while landing",
       description="drone sep while landing",
       default=1.5,
    )
     
    drone_dist_: bpy.props.FloatProperty(
        name="Drone Distance",
        description="drone distance",
        default=2.2,
    )

    speed_: bpy.props.FloatProperty(
        name="Speed",
        description="speed of the drone",
        default=4,
    )

    threshold_: bpy.props.FloatProperty(
        name="Threshold",
        description="threshold speed: Recommended to keep this unchanged (value=0.001)",
        default=0.001,
    )
    offset_: bpy.props.IntProperty(
        name="Offset keyframe",
        description="Offset keyframe",
        default=0,
    )


class drone_landing_apf_setup(bpy.types.Panel):
    bl_label = "APF_landing"
    bl_idname = "OBJECT_PT_drone_setup"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Landing'

    def draw(self, context):

        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool.apf
            
        row = layout.row(align=True)
        row.prop(mytool, "height_for_scaled_grid_")
        row = layout.row(align=True)
        row.prop(mytool, "height_for_descend_")
        row = layout.row(align=True)
        row.prop(mytool, "height_for_end_position_")
        row = layout.row(align=True)
        row.prop(mytool, "drone_sep_while_landing")
        row = layout.row(align=True)
        row.prop(mytool,"drone_dist_")
        row = layout.row(align=True)
        row.prop(mytool,"speed_")
        row = layout.row(align=True)
        row.prop(mytool,"threshold_")
        row = layout.row(align=True)
        row.prop(mytool, "offset_")
        row = layout.row(align=True)
        self.layout.operator('mesh.landing')


class drone_landing_apf(bpy.types.Operator):
    """Transfer effector color to all drones inside effector."""

    bl_label = "Snowfall"
    bl_idname = "mesh.landing"

    def execute(self, context):

        mytool = bpy.context.scene.my_tool.apf
        height_for_end_position_ =mytool.height_for_end_position_
        height_for_descend_=mytool.height_for_descend_
        height_for_scaled_grid_=mytool.height_for_scaled_grid_
        drone_dist_=mytool.drone_dist_
        drone_sep_while_landing=mytool.drone_sep_while_landing
        speed_=mytool.speed_
        threshold_=mytool.threshold_
        offset_=mytool.offset_        

        # Input Validation
        
        # Get a list of selected objects
        selected_objects = bpy.context.selected_objects
        if any(x for x in selected_objects if METADATA_SPHERE not in x) == True:
            self.report({'ERROR'},'Please select sphere only')
            return {'CANCELLED'}

        if not selected_objects:
            self.report({'ERROR'},'Please select atleast one sphere')
            return {'CANCELLED'}

        obj11 = selected_objects[0]
        # Check if the object has constraints
        if obj11.constraints:
            if (any([x for x in obj11.constraints if x.influence == 1])):
                self.report({'ERROR'},'Please disinfluence all the drones first')
                return {'CANCELLED'}
        

        if (height_for_scaled_grid_ <= 0) or (height_for_end_position_ <= 0) or (height_for_descend_ <= 0) or (drone_dist_ <= 0) or (drone_sep_while_landing <= 0) or (speed_ <= 0) or (threshold_ <= 0) or (offset_ <= 0):
            self.report({'ERROR'}, 'Every input value should be greater than 0')
            return {'CANCELLED'}
                    
        if not ((height_for_scaled_grid_ > height_for_descend_)  and (height_for_descend_ > height_for_end_position_)) :
            self.report({'ERROR'},'Order : height_for_scaled_grid_ > height_for_descend_ > height_for_end_position_ ')
            return {'CANCELLED'}
        
        prefetch = {}
        # # to prefetch the sphere 
        for obj in selected_objects:  # Access object by name
            prefetch[obj.get(METADATA_SPHERE)] = obj
          
        # for fetching the start positions' coordinates
        num_drones = 0
        for selected_object in selected_objects:
            num_drones += 1

        # Create an empty list to store object locations as tuples
        start_positions = [0]*num_drones
        # Iterate through selected objects
        for selected_object in selected_objects:
            # Get the location of the selected object
            object_location = selected_object.location
            # Convert Vector to a tuple
            object_location_tuple = tuple(object_location)
            #start_positions.append(object_location_tuple)
            start_positions[int(selected_object[METADATA_SPHERE][:len(selected_object[METADATA_SPHERE])-1])-1]=object_location_tuple
        
        # for fetching the landing_positions' coordinates

        landing_positions = []
        # Get the positions of empties
        empty_positions = [obj.location for obj in bpy.context.scene.objects if METADATA_EMPTYLAND in obj]
       
        # Print the positions
        for i, pos in enumerate(empty_positions):
            landing_positions.append((pos[0],pos[1]))
                            
        print('start -',start_positions,'\n','end -',landing_positions,'\n','heights -', height_for_end_position_, height_for_descend_, height_for_scaled_grid_,'\n','sep -',drone_sep_while_landing)    

        # Code Starts from here
        # dictionary to store the current positions of the drones by dividing the x, y and z co-ordinates into groups of 2 units each
        dict_store={}
        # stores the positions of all the drones for all the time steps so the position of drone i at iteration j 
        # can be found at drones_current[i][j] (considering that the drone number as well as the iteration number starts from 0)
        drones_current=[]
        # list of the goal locations on an extended grid of the landing positions at some height from the ground
        drones_goal_ordered=[]
        # list of radii of the extended drones
        drones_radii=[]
        # region of influence i.e. the region within which another drone would experience a repulsive potential from this drone
        n_oi="*"

        def is_reached():
            """is_reached() tells whether all the drones have reached to their goal positions on the extended grid returns True if all 
            the drones have reached their goal positions on the extended grid returns False if there is any drone that has not reached 
            its goal position on the extended grid
            """
            global drones_goal_ordered, drones_current, acc_error
            # check whether the current location of all the drones are close enough to the goal locations
            for i in range(len(drones_goal_ordered)):
                if ((drones_current[i][len(drones_current[i])-1][0]-drones_goal_ordered[i][0])**2+ \
                    (drones_current[i][len(drones_current[i])-1][1]-drones_goal_ordered[i][1])**2+ \
                    (drones_current[i][len(drones_current[i])-1][2]-drones_goal_ordered[i][2])**2)**0.5>=acc_error:
                    return False
            return True

        def add_to_dict(drone_id,pos):
            """add_to_dict adds the position pos of the drone with drone_id in the dictionary dict_store
            """
            global dict_store
            # checks whether the grouping where x-coordinate of pos will lie in is already there in the dictionary
            # if not there already, insert it as an key with empty dictionary as the value
            if pos[0]//2*2 not in dict_store:
                dict_store[int(pos[0]//2*2)]={}
            # checks whether the grouping where y-coordinate of pos will lie in is already there in the dictionary
            # if not there already, insert it as an key with empty dictionary as the value
            if pos[1]//2*2 not in dict_store[pos[0]//2*2]:
                dict_store[int(pos[0]//2*2)][int(pos[1]//2*2)]={}
            # checks whether the grouping where z-coordinate of pos will lie in is already there in the dictionary
            # if not there already, insert it as an key with empty dictionary as the value
            if pos[2]//2*2 not in dict_store[pos[0]//2*2][pos[1]//2*2]:
                dict_store[int(pos[0]//2*2)][int(pos[1]//2*2)][int(pos[2]//2*2)]={}
            # insert the drone having drone_id at the respective grouping of x, y and z coordinates and give its value as the position 
            dict_store[int(pos[0]//2*2)][int(pos[1]//2*2)][int(pos[2]//2*2)][drone_id]=pos

        def remove_from_dict(drone_id,pos):
            """remove_from_dict removes the position pos of the drone with drone_id from the dictionary dict_store
            """
            global dict_store
            # check whether the element pos for drone_id is already there in the dictionary
            # if not, return "Not present"
            if pos[0]//2*2 not in dict_store or pos[1]//2*2 not in dict_store[pos[0]//2*2] or \
            pos[2]//2*2 not in dict_store[pos[0]//2*2][pos[1]//2*2] or \
            drone_id not in dict_store[pos[0]//2*2][pos[1]//2*2][pos[2]//2*2]:
                return "Not present"
            
            # delete the drone_id having that grouping of positions 
            del(dict_store[pos[0]//2*2][pos[1]//2*2][pos[2]//2*2][drone_id])
            # check whether the z-coordinate grouping of the respective grouping is empty after deletion of this drone_id
            if dict_store[pos[0]//2*2][pos[1]//2*2][pos[2]//2*2]=={}:
                del(dict_store[pos[0]//2*2][pos[1]//2*2][pos[2]//2*2])
            # check whether the y-coordinate grouping of the respective grouping is empty after deletion of this drone_id
            if dict_store[pos[0]//2*2][pos[1]//2*2]=={}:
                del(dict_store[pos[0]//2*2][pos[1]//2*2])
            # check whether the x-coordinate grouping of the respective grouping is empty after deletion of this drone_id
            if dict_store[pos[0]//2*2]=={}:
                del(dict_store[pos[0]//2*2])

        def nearby_in_dict(drone_id,pos):
            """find the drones which have possibility of being in the region of influence of the drone with drone_id and at position pos
            """
            global drones_radii, dict_store, n_oi
            nearby=[]
            # loop over the possible x-coordinate values for the nearby drones
            for x in range(int((pos[0]-2*drones_radii[drone_id]-n_oi)//2*2),int((pos[0]+2*drones_radii[drone_id]+n_oi)//2*2)+1,2):
                if x not in dict_store:
                    continue
                # loop over the possible y-coordinate values for the nearby drones
                for y in range(int((pos[1]-2*drones_radii[drone_id]-n_oi)//2*2),int((pos[1]+2*drones_radii[drone_id]+n_oi)//2*2)+1,2):
                    if y not in dict_store[x]:
                        continue
                    # loop over the possible z-coordinate values for the nearby drones
                    for z in range(int((pos[2]-2*drones_radii[drone_id]-n_oi)//2*2),int((pos[2]+2*drones_radii[drone_id]+n_oi)//2*2)+1,2):
                        if z not in dict_store[x][y]:
                            continue
                        # found a possible drone
                        for drone in dict_store[x][y][z]:
                            # check whether the drone we have found is itself the drone for which nearby neighbours need to be found
                            if drone==drone_id:
                                continue
                            else:
                                nearby.append((dict_store[x][y][z][drone],drone))
            return nearby

        def trajectory(drones_start,drones_landing_ordered,height_for_end_position,height_for_descend,height_for_scaled_grid,drone_sep_while_landing,offset,drone_dist=2.2,speed=4,threshold=0.001):
            """This function finds the waypoints for each drone 
            It takes 7 mandatory parameters and 3 optional parameters as input: 
            - drones_start is the list of starting positions of the drones
            - drones_landing_ordered is the list of (x,y) positions of the drones in the landing grid
            - height_for_end_position is the height above the ground where the landing algo should land the drones
            - height_for_descend is the height above the ground where drones must get aligned with their x and y coordinates of the landing grid and start descending
            - height_for_scaled_grid is the height above the ground where the scaled grid is getting formed 
            - drone_sep_while_landing is the inter-drone separation in the landing grid
            - offset is the keyframe number from where the landing needs to be started
            - drone_dist is the inter-drone separation in the extended grid
            - speed is the speed of the drones
            - threshold is the error threshold for approximating the waypoints as a straight line
            It gives the output as the list of waypoints for each drone, where each waypoint consists of the coordinates and the time step
            at which the respective drone should be at the corresponding coordinates
            """

            # the following parameters are defined in the code along with their first usage
            global drones_goal_ordered, drones_current, dict_store, drones_radii, n_oi, acc_error
            
            # check whether the distance between the drones from where landing has to be started is less than the minimum distance given as input
            for i in range(len(drones_start)):
                for j in range(i+1,len(drones_start)):
                    gap = ((drones_start[i][0]-drones_start[j][0])**2+(drones_start[i][1]-drones_start[j][1])**2+(drones_start[i][2]-drones_start[j][2])**2)**0.5
                    if gap<drone_dist:
                        print("Error: Actual drone distance in the formation is less than the drone distance given in input")
                        return
                    
            # check whether the order of heights is same as expected or not
            if height_for_end_position>height_for_descend or height_for_descend>=height_for_scaled_grid:
                print("Error: Incorrect order of heights is given as input")
                return
            
            # scaled grid should be atleast 5m above the height for descend
            if height_for_scaled_grid-height_for_descend<5:
                print("Error: Scaled grid is too close to the height for descend. Keep it atleast 5m above the height for descend.")
                return
            
            # speed should be positive
            if speed<=0:
                print("Error: Keep the speed as positive")
                return
            
            # find the center of mass along all the three axes for the formation from where landing has to be done
            cm_x,cm_y,cm_z=0,0,0
            for s1 in drones_start:
                cm_x+=s1[0]
                cm_y+=s1[1]
                cm_z+=s1[2]
            s1_x=cm_x/len(drones_start)
            s1_y=cm_y/len(drones_start)
            s1_z=cm_z/len(drones_start)

            # drones_btw is the grid of drone positions aligned with the landing grid and at an height above the ground 
            drones_btw=[]
            
            # min and max x and y co-ordinate values for the landing grid
            x_min=min(i[0] for i in drones_landing_ordered)
            x_max=max(i[0] for i in drones_landing_ordered)
            y_min=min(i[1] for i in drones_landing_ordered)
            y_max=max(i[1] for i in drones_landing_ordered)

            # accuracy error
            acc_error=0.5
            
            # fill the drones_btw grid and find the min and max in x and y for the drones
            for i in drones_landing_ordered:
                drones_btw.append((i[0],i[1],height_for_descend))

            # extended grid above the ground where the inter-drone separation is more than the landing grid
            drones_goal_ordered=[]

            # mid point of the landing grid on the x-coordinate
            x_mid=(x_min+x_max)/2
            # mid point of the landing grid on the y-coordinate
            y_mid=(y_min+y_max)/2

            # height of the extended grid above the drones_btw grid
            height_first_layer=height_for_scaled_grid-height_for_descend
    
            # finding the mid point of the scaled layer along all the three axes
            i=drones_btw[0][2]
            mid_x=((i+height_first_layer-height_for_descend)/(s1_z-height_for_descend))*(s1_x-x_mid)+x_mid
            mid_y=((i+height_first_layer-height_for_descend)/(s1_z-height_for_descend))*(s1_y-y_mid)+y_mid
            mid_z=i+height_first_layer
            
            print(mid_x,mid_y,mid_z)

            # fill the positions of the drones on the extended grid
            for i in drones_btw:
                drones_goal_ordered.append((mid_x+(i[0]-x_mid)/drone_sep_while_landing*drone_dist, \
                                            mid_y+(i[1]-y_mid)/drone_sep_while_landing*drone_dist, \
                                            mid_z))

            # radii of the extended drones
            drones_radii=[1]*len(drones_start)
            # time duration corresponding to each iteration
            time_instant=0.04

            # contains list of distances for each set of parameters
            distances=[]
            # minimum distance between any two drones over all the time instants
            n_min="*"
            # parameter for attractive potential
            Ka=[1.5]
            # parameter for repulsive potential
            Gamma=[2]
            # parameter for repulsive potential
            K_list=[0.5]
            # parameter for repulsive potential
            Noi=[4]
            # list of parameter combinations
            comb=[]
            for p1 in K_list:
                for p2 in Gamma:
                    for p3 in Ka:
                        for p4 in Noi:
                            comb.append((p1,p2,p3,p4))

            # minimum distance travelled by all the drones combined over all the parameter values
            m_dist=-1
            # parameter values for which the sum of distances travelled is minimum
            k_m,g_m,ka_m,noi_m=(0,0,0,0)

            # list which tells whether each drone has reached its respective position on the extended grid
            reached_list=[0]*len(drones_start)
            # list which tells whether each drone has reached its respective position on the drones_btw grid
            reached_betw=[0]*len(drones_start)
            # list which tells whether each drone has reached its respective position on the landing grid
            reached_down=[0]*len(drones_start)

            # stores the sum of distances travelled to reach the extended grid in case there was no obstacle
            straight_dist=0
            for i in range(len(drones_start)):
                straight_dist+=((drones_start[i][0]-drones_goal_ordered[i][0])**2+ \
                                (drones_start[i][1]-drones_goal_ordered[i][1])**2+ \
                                (drones_start[i][2]-drones_goal_ordered[i][2])**2)**0.5
            
            # stores the sum of distance travelled to reach the extended grid in case of presence of obstacles
            dist_till_goal=0
            global output
            # contains the waypoints for each drone as a list of list of waypoints for each drone
            output=[]

            # loop over all the parameter combinations
            for K,gamma,ka,n_oi in comb:
                dist_aligned=0
                # stores the positions of all the drones for all the time steps so the position of drone i at iteration j 
                # can be found at drones_current[i][j] (considering that the drone number as well as the iteration number starts from 0)
                drones_current=[]
                # stores the current position of all the drones in terms of grouping in x, y and z coordinates
                dict_store={}

                # stores the list of x-velocities over all the iterations for each drone
                vel_store_x=[]
                # stores the list of y-velocities over all the iterations for each drone
                vel_store_y=[]
                # stores the list of z-velocities over all the iterations for each drone
                vel_store_z=[]

                # add the starting position of the drones to drones_current and dict_store
                for i in range(len(drones_start)):
                    drones_current.append([drones_start[i]])
                    add_to_dict(i,drones_start[i])

                # keeps track of the iteration number
                iteration = 0

                # stores the amount of extra (imaginary) repulsion experienced by all the drones
                extra_rep=[0]*len(drones_start)
                # counts the number of time steps for which that particular extra repulsion has been applied to the drone
                count=[0]*len(drones_start)

                # till all the drones are reached to their position on the landing grid, this loop will go on
                while(reached_down!=[1]*len(drones_start)):

                    if iteration%1000 == 0:
                        print("Iteration count = "+str(iteration))

                    # increment the iteration number each time this while loop is enterred
                    iteration=iteration+1

                    # stores the new location of the drones for the current iteration
                    drones_current_iteration=[]
                    
                    # list of drone velocities in x, y and z respectively for all the drones
                    x_vel=[]
                    y_vel=[]
                    z_vel=[]
                    
                    # loop over all the drones to find their next position and next velocity
                    for i in range(len(drones_start)):
                        # if the drone has reached its position on the extended grid but not on its pos in drones_btw
                        if reached_list[i]==1 and reached_betw[i]!=1:
                            # distance between its current position and its position on drones_btw
                            dis=((drones_btw[i][0]-drones_current[i][iteration-1][0])**2+ \
                                 (drones_btw[i][1]-drones_current[i][iteration-1][1])**2+ \
                                 (drones_btw[i][2]-drones_current[i][iteration-1][2])**2)**0.5
                            # unit vector towards its position on drones_btw
                            x_d=(drones_btw[i][0]-drones_current[i][iteration-1][0])/dis
                            y_d=(drones_btw[i][1]-drones_current[i][iteration-1][1])/dis
                            z_d=(drones_btw[i][2]-drones_current[i][iteration-1][2])/dis
                            # scale the unit vector by speed and append it to the velocity list
                            x_vel.append(x_d*speed)
                            y_vel.append(y_d*speed)
                            z_vel.append(z_d*speed)
                            # store the next position of the current drone
                            drones_current_iteration.append((drones_current[i][iteration-1][0]+x_vel[i]*time_instant, \
                                                             drones_current[i][iteration-1][1]+y_vel[i]*time_instant, \
                                                             drones_current[i][iteration-1][2]+z_vel[i]*time_instant))
                            
                            dist_aligned+=((drones_current[i][iteration-1][0]-drones_current_iteration[i][0])**2+\
                                           (drones_current[i][iteration-1][1]-drones_current_iteration[i][1])**2+\
                                           (drones_current[i][iteration-1][2]-drones_current_iteration[i][2])**2)**0.5
                            
                            # if this drone has now reached its position on drones_btw, store it in reached_btw as 1
                            if ((drones_btw[i][0]-drones_current_iteration[i][0])**2+ \
                                (drones_btw[i][1]-drones_current_iteration[i][1])**2+ \
                                (drones_btw[i][2]-drones_current_iteration[i][2])**2)**0.5<=speed*time_instant:
                                reached_betw[i]=1
                            continue
                        # if the drone has reached its position in drones_btw
                        elif reached_betw[i]==1:
                            # if the current position and its position on the landing grid are close enough
                            if abs(drones_current[i][iteration-1][2]-height_for_end_position)<=speed*time_instant:
                                drones_current_iteration.append(drones_current[i][iteration-1])
                                # stay at that position
                                z_vel.append(0)
                                # reached the position on the landing grid
                                reached_down[i]=1
                            # if it has not yet reached its landing grid position
                            else:
                                # descend it in the z-direction
                                drones_current_iteration.append((drones_current[i][iteration-1][0], \
                                                                 drones_current[i][iteration-1][1], \
                                                                 drones_current[i][iteration-1][2]-speed*time_instant))
                                # has a velocity along z-direction
                                z_vel.append(-1*speed)
                            # velocities are zero along x and y directions
                            x_vel.append(0)
                            y_vel.append(0)
                            continue

                        # gradient in x (attractive potential)
                        x_vel.append(ka*(drones_goal_ordered[i][0]-drones_current[i][len(drones_current[i])-1][0]))
                        # gradient in y (attractive potential)
                        y_vel.append(ka*(drones_goal_ordered[i][1]-drones_current[i][len(drones_current[i])-1][1]))
                        # gradient in z (attractive potential)
                        z_vel.append(ka*(drones_goal_ordered[i][2]-drones_current[i][len(drones_current[i])-1][2]))
                
                        # find the drones for which the current drone is in region of influence, 
                        # i.e. the drones which will repel the current drone
                        nearby_drones=nearby_in_dict(i,drones_current[i][iteration-1])
                        for j in range(len(nearby_drones)):
                            # distance between the current drone and the nearby drone
                            d=((nearby_drones[j][0][0]-drones_current[i][len(drones_current[i])-1][0])**2+ \
                               (nearby_drones[j][0][1]-drones_current[i][len(drones_current[i])-1][1])**2+ \
                               (nearby_drones[j][0][2]-drones_current[i][len(drones_current[i])-1][2])**2)**0.5   
                            # distance between the current drone and the nearby drone measured from the surfaces of the extended drones
                            n=d-2*drones_radii[i]
                            # if n_min is undefined then give it a value as n
                            if n_min=="*":
                                n_min=n
                            # n_min should be the minimum of the new n and the earlier value of n_min
                            n_min=min(n_min,n)

                            if n<=0:
                                # give n a small positive value close to zero
                                n=10**(-10)

                            if n<=n_oi:
                                # if near the obstacle, a repulsive gradient will be added
                                x_vel[i]=x_vel[i]+K*((1/n-1/n_oi)**(gamma-1))*(-1/n**2)*(1/(2*d))*2* \
                                         (-drones_current[i][len(drones_current[i])-1][0]+nearby_drones[j][0][0])     
                                y_vel[i]=y_vel[i]+K*((1/n-1/n_oi)**(gamma-1))*(-1/n**2)*(1/(2*d))*2* \
                                         (-drones_current[i][len(drones_current[i])-1][1]+nearby_drones[j][0][1])
                                z_vel[i]=z_vel[i]+K*((1/n-1/n_oi)**(gamma-1))*(-1/n**2)*(1/(2*d))*2* \
                                         (-drones_current[i][len(drones_current[i])-1][2]+nearby_drones[j][0][2])
                        
                        # check if there is an imaginary repulsive potential to be added to the current drone
                        if extra_rep[i]!=0:
                            x_vel[i]=x_vel[i]+extra_rep[i][0]
                            y_vel[i]=y_vel[i]+extra_rep[i][1]
                            z_vel[i]=z_vel[i]+extra_rep[i][2]
                            # increment the time steps for which the imaginary repulsive potential is applied
                            count[i]+=1
                            if count[i]==20:
                                # remove the imaginary repulsive potential after 20 time steps
                                count[i]=0
                                extra_rep[i]=0
                        else:
                            # scale the velocity so that the magnitude of overall velocity is same as the desired speed
                            vel=(x_vel[i]**2+y_vel[i]**2+z_vel[i]**2)**0.5
                            if vel!=0:
                                x_vel[i]=speed*(x_vel[i]/vel)
                                y_vel[i]=speed*(y_vel[i]/vel)
                                z_vel[i]=speed*(z_vel[i]/vel)
                            else:
                                x_vel[i]=0
                                y_vel[i]=0
                                z_vel[i]=0

                            # new position for the current drone based on the velocity till now
                            new_pos=(drones_current[i][len(drones_current[i])-1][0]+time_instant*x_vel[i], \
                                     drones_current[i][len(drones_current[i])-1][1]+time_instant*y_vel[i], \
                                     drones_current[i][len(drones_current[i])-1][2]+time_instant*z_vel[i])

                            # we need to compare with the last 10 time steps to check whether a drone is stuck at a position 
                            if len(drones_current[i])>=10:
                                flag=0
                                # min and max of the positions for the last 10 time steps plus the new time step in all the three axes
                                min_x=min(drones_current[i][len(drones_current[i])-1-it][0] for it in range(10))
                                min_y=min(drones_current[i][len(drones_current[i])-1-it][1] for it in range(10))
                                min_z=min(drones_current[i][len(drones_current[i])-1-it][2] for it in range(10))
                                max_x=max(drones_current[i][len(drones_current[i])-1-it][0] for it in range(10))
                                max_y=max(drones_current[i][len(drones_current[i])-1-it][1] for it in range(10))
                                max_z=max(drones_current[i][len(drones_current[i])-1-it][2] for it in range(10))
                                
                                min_x=min(min_x,new_pos[0])
                                min_y=min(min_y,new_pos[1])
                                min_z=min(min_z,new_pos[2])
                                max_x=max(max_x,new_pos[0])
                                max_y=max(max_y,new_pos[1])
                                max_z=max(max_z,new_pos[2])

                                # check whether the drone is stuck around a position
                                if max_x-min_x<=speed*time_instant and max_y-min_y<=speed*time_instant and max_z-min_z<=speed*time_instant:
                                    flag=0
                                else:
                                    flag=1
                                # flag=0 means that the drone is stuck around a position
                                if flag==0:
                                    # if the drone is stuck but it has not yet reached its goal position on the extended grid
                                    if ((drones_current[i][len(drones_current[i])-1][0]-drones_goal_ordered[i][0])**2+ \
                                        (drones_current[i][len(drones_current[i])-1][1]-drones_goal_ordered[i][1])**2+ \
                                        (drones_current[i][len(drones_current[i])-1][2]-drones_goal_ordered[i][2])**2)**0.5>=acc_error:

                                        for it in range(1,9):
                                            drones_current[i][len(drones_current[i])-1-it]=drones_current[i][len(drones_current[i])-10]

                                        # random constant parameter value for the imaginary repulsive potential
                                        const=random.random()*5
                                        # distance between the current and goal position on the extended grid along each of the axes
                                        k1=drones_goal_ordered[i][0]-drones_current[i][len(drones_current[i])-1][0]
                                        k2=drones_goal_ordered[i][1]-drones_current[i][len(drones_current[i])-1][1]
                                        k3=drones_goal_ordered[i][2]-drones_current[i][len(drones_current[i])-1][2]
                                        if k1==0:
                                            d1=0
                                        else:
                                            d1=-1*(k2+k3)/k1
                                        d2=1
                                        d3=1

                                        # position of the imaginary obstacle that will exert a repulsive potential
                                        obs_x=d1+drones_current[i][len(drones_current[i])-1][0]
                                        obs_y=d2+drones_current[i][len(drones_current[i])-1][1]
                                        obs_z=d3+drones_current[i][len(drones_current[i])-1][2]

                                        d=(d1**2+d2**2+d3**2)**0.5
                                        n=d-drones_radii[i]
                                        # adding the imaginary repulsive potential exerted by the imaginary obstacle along all three axes
                                        x_vel[i]=x_vel[i]+const*((1/n-1/n_oi)**(gamma-1))*(-1/n**2)*(1/(2*d))*2* \
                                                 (obs_x-drones_current[i][len(drones_current[i])-1][0])     
                                        y_vel[i]=y_vel[i]+const*((1/n-1/n_oi)**(gamma-1))*(-1/n**2)*(1/(2*d))*2* \
                                                 (obs_y-drones_current[i][len(drones_current[i])-1][1])
                                        z_vel[i]=z_vel[i]+const*((1/n-1/n_oi)**(gamma-1))*(-1/n**2)*(1/(2*d))*2* \
                                                 (obs_z-drones_current[i][len(drones_current[i])-1][2])
                                        # store the imaginary repulsive potential value for the current drone
                                        extra_rep[i]=(const*((1/n-1/n_oi)**(gamma-1))*(-1/n**2)*(1/(2*d))*2* \
                                                      (obs_x-drones_current[i][len(drones_current[i])-1][0]), \
                                                      const*((1/n-1/n_oi)**(gamma-1))*(-1/n**2)*(1/(2*d))*2* \
                                                      (obs_y-drones_current[i][len(drones_current[i])-1][1]), \
                                                      const*((1/n-1/n_oi)**(gamma-1))*(-1/n**2)*(1/(2*d))*2* \
                                                      (obs_z-drones_current[i][len(drones_current[i])-1][2]))
                                        # count of the time steps for which this imaginary repulsive potential is exerted
                                        count[i]=1

                        # if the current drone is reached to its location on the extended grid, it does not need to move 
                        if ((drones_current[i][len(drones_current[i])-1][0]-drones_goal_ordered[i][0])**2+ \
                            (drones_current[i][len(drones_current[i])-1][1]-drones_goal_ordered[i][1])**2+ \
                            (drones_current[i][len(drones_current[i])-1][2]-drones_goal_ordered[i][2])**2)**0.5<acc_error:
                            x_vel[i]=0
                            y_vel[i]=0
                            z_vel[i]=0

                        # if the current drone has not reached its position on the extended grid but its z-coordinate is close enough to the 
                        # z-coordinate of this extended grid, then there would be no movement in the z-direction
                        if reached_list[i]==0 and  \
                        drones_goal_ordered[i][2]<=drones_current[i][iteration-1][2]<=drones_goal_ordered[i][2]+speed*time_instant:
                            z_vel[i]=0

                        # scale the velocity so that its magnitude becomes equal to the desired speed
                        vel=(x_vel[i]**2+y_vel[i]**2+z_vel[i]**2)**0.5
                        if vel!=0:
                            x_vel[i]=speed*(x_vel[i]/vel)
                            y_vel[i]=speed*(y_vel[i]/vel)
                            z_vel[i]=speed*(z_vel[i]/vel)
                        else:
                            x_vel[i]=0
                            y_vel[i]=0
                            z_vel[i]=0

                        # find the new position of the current drone based on this velocity
                        new_pos=(drones_current[i][len(drones_current[i])-1][0]+time_instant*x_vel[i], \
                                 drones_current[i][len(drones_current[i])-1][1]+time_instant*y_vel[i], \
                                 drones_current[i][len(drones_current[i])-1][2]+time_instant*z_vel[i])
                        drones_current_iteration.append(new_pos)
                        
                        dist_aligned+=((drones_current[i][iteration-1][0]-drones_current_iteration[i][0])**2+\
                                           (drones_current[i][iteration-1][1]-drones_current_iteration[i][1])**2+\
                                           (drones_current[i][iteration-1][2]-drones_current_iteration[i][2])**2)**0.5
                                           
                        # update the actual distance till the extended grid for the current iteration of the current drone
                        dist_till_goal+=((new_pos[0]-drones_current[i][iteration-1][0])**2+ \
                                         (new_pos[1]-drones_current[i][iteration-1][1])**2+ \
                                         (new_pos[2]-drones_current[i][iteration-1][2])**2)**0.5
                        # if the new position of the current drone is close enough to its position on the extended grid, then update in the list
                        if ((new_pos[0]-drones_goal_ordered[i][0])**2+ \
                            (new_pos[1]-drones_goal_ordered[i][1])**2+ \
                            (new_pos[2]-drones_goal_ordered[i][2])**2)**0.5<acc_error:
                            reached_list[i]=1
                        
                    # store the velocities for the current iteration
                    vel_store_x.append(x_vel)
                    vel_store_y.append(y_vel)
                    vel_store_z.append(z_vel)

                    for i in range(len(drones_start)):
                        # for each drone, update its new position in drones_current as well as in dict_store
                        drones_current[i].append(drones_current_iteration[i])
                        remove_from_dict(i,drones_current[i][iteration-1])
                        add_to_dict(i,drones_current[i][iteration])

                        # check whether any drone crosses the extended grid without reaching its goal on the extended grid 
                        if drones_current[i][len(drones_current[i])-1][2]<drones_goal_ordered[i][2] and reached_list[i]!=1:
                            print("Drone "+str(i)+" reached below extended grid without reaching its goal on the extended grid")
                            print(drones_goal[i])
                            print("Parameters are Ka = "+str(ka)+" noi = "+str(n_oi)+" K= "+str(K)+" gamma = "+str(gamma))
                            print(drones_current[i][iteration-1][2])
                            exit()

                # calculate the sum of distances travelled by all the drones
                sum_of_distances = 0
                for i in range(len(drones_start)):
                    for j in range(1,len(drones_current[i])):
                        sum_of_distances+=((drones_current[i][j][0]-drones_current[i][j-1][0])**2+ \
                                           (drones_current[i][j][1]-drones_current[i][j-1][1])**2+ \
                                           (drones_current[i][j][2]-drones_current[i][j-1][2])**2)**0.5

                distances.append(sum_of_distances)

                # update m_dist and the parameters which lead to the minimum distance travelled
                if m_dist==-1:
                    m_dist=sum_of_distances
                    k_m,g_m,ka_m,noi_m=K,gamma,ka,n_oi
                else:
                    if sum_of_distances<m_dist:
                        m_dist=min(m_dist,sum_of_distances)
                        k_m,g_m,ka_m,noi_m=K,gamma,ka,n_oi

                # stores the velocties along with time steps where the direction of velocity is changed
                vel_changes_using_vel=[]
                for i in range(len(drones_start)):
                    vel_changes_using_vel.append([])
                    # directly store the velocity for the first time step
                    for k in range(1):
                        vel_changes_using_vel[i].append((vel_store_x[k][i],vel_store_y[k][i],vel_store_z[k][i],k))
                    # for the remaining time steps, store the velocity only where its direction is changed i.e. when the position reached
                    # on following the previous velocity is close enough to the next position
                    for j in range(1,len(drones_current[0])-2):
                        app_x=drones_current[i][j][0]+vel_changes_using_vel[i][len(vel_changes_using_vel[i])-1][0]*time_instant
                        app_y=drones_current[i][j][1]+vel_changes_using_vel[i][len(vel_changes_using_vel[i])-1][1]*time_instant
                        app_z=drones_current[i][j][2]+vel_changes_using_vel[i][len(vel_changes_using_vel[i])-1][2]*time_instant
                        if ((app_x-drones_current[i][j+1][0])**2+(app_y-drones_current[i][j+1][1])**2+ \
                        (app_z-drones_current[i][j+1][2])**2)**0.5>threshold:
                            vel_changes_using_vel[i].append((vel_store_x[j][i],vel_store_y[j][i],vel_store_z[j][i],j))
                    
                    # if the last velocity is not zero, append a zero velocity since after reaching its final position it has to be zero
                    if vel_changes_using_vel[i][len(vel_changes_using_vel[i])-1][0]!=0 or \
                    vel_changes_using_vel[i][len(vel_changes_using_vel[i])-1][1]!=0 or \
                    vel_changes_using_vel[i][len(vel_changes_using_vel[i])-1][2]!=0:
                        vel_changes_using_vel[i].append((0,0,0,j+1))

                # actual drone positions using the velocity approximations
                drones_current_actual=[]
                for i in range(len(drones_start)):
                    drones_current_actual.append([drones_start[i]])
                    output.append([])

                pointers=[0]*len(drones_start)
                for i in range(iteration):
                    for j in range(len(drones_start)):
                        flag=1
                        # check whether the current time step is a waypoint for the current drone
                        if 0<=pointers[j]<len(vel_changes_using_vel[j]) and vel_changes_using_vel[j][pointers[j]][3]==i:
                            flag=0
                            
                        drones_current_actual[j].append((drones_current_actual[j][len(drones_current_actual[j])-1][0]+ \
                                                         time_instant*vel_changes_using_vel[j][pointers[j]-flag][0], \
                                                         drones_current_actual[j][len(drones_current_actual[j])-1][1]+ \
                                                         time_instant*vel_changes_using_vel[j][pointers[j]-flag][1], \
                                                         drones_current_actual[j][len(drones_current_actual[j])-1][2]+ \
                                                         time_instant*vel_changes_using_vel[j][pointers[j]-flag][2]))
                        if flag==0:
                            # increment the pointer
                            pointers[j]+=1
                            # append the new position as a waypoint of the current drone 
                            output[j].append((drones_current[j][i],offset+i))

                print("min n is "+str(n_min))
                
                # to remove the vibrations, ignore the waypoints which are very close to each other over a specific duration
                for i in range(len(output)):
                    j=0
                    while j<len(output[i]):
                        # initialise the min and max in all the three directions with the current waypoint
                        min_x=output[i][j][0][0]
                        min_y=output[i][j][0][1]
                        min_z=output[i][j][0][2]
                        max_x=output[i][j][0][0]
                        max_y=output[i][j][0][1]
                        max_z=output[i][j][0][2]
                        flag=j
                        for k in range(len(output[i])-j):
                            # keep on computing the min and max in all the three directions 
                            min_x=min(min_x,output[i][j+k][0][0])
                            max_x=max(max_x,output[i][j+k][0][0])
                            min_y=min(min_y,output[i][j+k][0][1])
                            max_y=max(max_y,output[i][j+k][0][1])
                            min_z=min(min_z,output[i][j+k][0][2])
                            max_z=max(max_z,output[i][j+k][0][2])
                            
                            # check whether drone has stayed within a cube of body diagonal of length 0.6
                            if ((max_x-min_x)**2+(max_y-min_y)**2+(max_z-min_z)**2)**0.5<0.6:
                                # if yes, the last waypoint till now which lies in the current cube has j+k index 
                                # and we need to check the same for the following waypoints
                                flag=j+k
                                continue
                            else:
                                # if no, the last waypoint which lies in the current cube has j+k-1 index 
                                # and we need to make a new cube starting from the current waypoint
                                flag=j+k-1
                                break
                        # duration between the last waypoint lying in the cube to the first waypoint lying in it                       
                        duration=output[i][flag][1]-output[i][j][1]+1
                        
                        # if duration is more than 1, i.e. there is an approximation possible
                        if duration>=2:
                            # nullify the waypoints lying between the first and last waypoint in this cube
                            for k in range(j+1,flag):
                                output[i][k]=(output[i][k][0],"null")
                            # start forming the cube again from the next waypoint
                            j=flag+1
                        else:
                            # if duration was just 1, i.e. no approximation was possible, then start forming a cube again from the next waypoint
                            j+=1
                
                # make the landing z-coordinate of all the drones equal to the height required to be landed at
                for i in range(len(output)):
                    # if the drone is slightly lower to the height required, make the last z-coordinate same as the required height with the same keyframe
                    if output[i][len(output[i])-1][0][2]<height_for_end_position:
                        output[i][len(output[i])-1]=((output[i][len(output[i])-1][0][0],output[i][len(output[i])-1][0][1],height_for_end_position),output[i][len(output[i])-1][1])
                    # if the drone is slightly above to the height required, make the last z-coordinate same as the required height with the next keyframe
                    elif output[i][len(output[i])-1][0][2]>height_for_end_position:
                        output[i][len(output[i])-1]=((output[i][len(output[i])-1][0][0],output[i][len(output[i])-1][0][1],height_for_end_position),output[i][len(output[i])-1][1]+1)
                                      
            return output
            
        # distance between the drones, speed and error threshold are the optional parameters which can be used as well
        print('start -',start_positions,'\n','end -',landing_positions,'\n','heights -',height_for_end_position_,height_for_descend_,height_for_scaled_grid_,'\n','sep -',drone_sep_while_landing) 
        trajectory(start_positions,landing_positions,height_for_end_position_,height_for_descend_,height_for_scaled_grid_,drone_sep_while_landing,offset_,drone_dist_,speed_,threshold_)
        print('I am here')

        for drone_index, drone_data in enumerate(output):
            print('I am here 2---- ',drone_index)
            name = f"{drone_index+1}S" 
            drone = prefetch.get(name)  # Initialize drone variable

            # Set keyframes for each waypoint
            for frame, ((x, y, z), waypoint_frame) in enumerate(drone_data):
                if waypoint_frame=="null":
                    continue
                # bpy.context.scene.frame_set(waypoint_frame)
                drone.location = (x, y, z)
                drone.keyframe_insert(data_path="location", frame=waypoint_frame)  

        # Set the animation length
        animation_length=0
        for drone_data in output:
            for _, waypoint in enumerate(drone_data):
                if waypoint[1]!="null":
                    animation_length=max(animation_length,waypoint[1])

        bpy.context.scene.frame_end = animation_length

        # Play the animation
        bpy.ops.screen.animation_play()

        return {'FINISHED'}    


