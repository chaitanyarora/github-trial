import bpy
import math
import time

class my_properties(bpy.types.PropertyGroup):
    drone_speed: bpy.props.FloatProperty(
       name="Speed (m/sec)",
       description="Speed of the Drone in m/sec",
       min=1.0,   # Set the lower limit
       max=3.0,
       default=2.0,
    )
   
    total_drones: bpy.props.IntProperty(
       name="Total drones",
       description="Total number of Drones",
       default=0,
    )
   
    start_frame: bpy.props.IntProperty(
       name="Start frame",
       description="Starting frame",
       default=0,
    )
   
    distance: bpy.props.FloatProperty(
       name="Drone collision (m)",
       description="threshold for collision avoidance",
       default=2.5,
    )
   
    time_delay: bpy.props.FloatProperty(
       name="delay",
       description="delay in landing for collison avoidance",
       default=0.4,
    )
   
   
class priority_delay_panel(bpy.types.Panel):
    """Creates a Panel in the Object properties Window"""
    bl_label = "PL Landing"
    bl_idname = "OBJECT_PT_priority_delay_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Landing"

    def draw(self, context):
        layout = self.layout
 
        scene = context.scene
        mytool = scene.my_tool.pd

        row = layout.row(align=True)
        row.prop(mytool, "drone_speed")

        row = layout.row(align=True)
        row.prop(mytool, "total_drones")
       
        row = layout.row(align=True)
        row.prop(mytool, "start_frame")
       
        row = layout.row(align=True)
        row.prop(mytool, "distance")
       
        row = layout.row(align=True)
        row.prop(mytool, "time_delay")
        
        row = layout.row()
        row.operator("object.priority_delay_algorthim")

   
# Define a new operator class
class priority_delay_algorthm(bpy.types.Operator):
    # The ID name of the operator (must be unique)
    bl_idname = "object.priority_delay_algorthim"
    # The display name of the operator
    bl_label = "PD Land"

    # The main execution function of the operator
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool.pd
        stop_frame_period=(mytool.time_delay)*24
            
        land_frame=[0]*mytool.total_drones
        final_target=[0]*mytool.total_drones

    
        stop_semaphore=[0]*mytool.total_drones
        stop_frame=[0]*mytool.total_drones

        reached_flag=[0]*mytool.total_drones
      
    
        #Go to intial point
        for drone in bpy.context.scene.objects:
            if (drone.name[-1] == 'S'):  
                drone_number=drone.name[:-1]
                for empty in bpy.context.scene.objects:
                    if "E" in empty.name :
                        if("E0" == empty.name[-2: ]):    
                            empty_number=empty.name[:-2]
                            if(drone_number==empty_number):
                                current_height= drone.location.z
                                current_x=drone.location.x
                                current_y=drone.location.y
                                
                                drone.location.x = empty.location.x
                                drone.location.y = empty.location.y
                                drone.location.z = empty.location.z+5 # offset of 5
                                
                                # add frame to maintain required speed
                                target_x=empty.location.x
                                target_y=empty.location.y
                                target_height=empty.location.z+5
                                time=(((current_x-target_x)**2+(current_y-target_y)**2+(current_height-target_height)**2)**(1/2))/mytool.drone_speed
                                f1_delay=24*time
                                land_frame[int(drone.name[:-1])-1]=mytool.start_frame+f1_delay
                                drone.keyframe_insert(data_path="location", frame=land_frame[int(drone.name[:-1])-1])
                                final_target[int(drone.name[:-1])-1]=empty
        # print("landing_frame:"+str(land_frame))
       
        
        # ####################################################################################################
        # #collision_avoidance in column side
        sce = bpy.context.scene
        d_threshold = mytool.distance*100# distance threshold in meters
        scale = 1
        print("\nRunning distance check\n")

        starting_frame=mytool.start_frame

        drone=[]
        for i in range(1, mytool.total_drones+1):
            drone.append(str(i)+"S")

      
        f=starting_frame
        reached=min(reached_flag)
        while(reached==0):
            if((f-1) % 1 == 0):
                  sce.frame_set(f)
                  for i in range(len(drone)):
                    # scanning all drones one by one  
                    ob = bpy.data.objects[drone[i]]
                    #print("\n Checking Sphere " + drone[i])
                    x = int(ob.matrix_world.to_translation().x * scale)
                    y = int(ob.matrix_world.to_translation().y * scale)
                    z = int(ob.matrix_world.to_translation().z * scale)
                   
                    lower = 1
                    upper = mytool.total_drones

                    empty=final_target[int(ob.name[:-1])-1]   
                    target_x=empty.location.x
                    target_y=empty.location.y
                    target_height=empty.location.z+5



                    # reached
                    if(abs(z-empty.location.z)<1):    
                                reached_flag[i]=1                        
                    elif(abs(z-empty.location.z-5)<1):
                                #ob.location.z = empty.location.z   
                                reached_flag[i]=1   
                                #land_frame[i]= land_frame[i]+((5/mytool.drone_speed)*24)              
                                #ob.keyframe_insert(data_path="location", frame=land_frame[i])

                    
                    
                    x=x*100
                    y=y*100
                    z=z*100
                    # waiting to avoid collision
                    if(stop_semaphore[i]==1):
                        if(f >= stop_frame[i]):
                            stop_semaphore[i]=0
                           
                            
                    if(reached_flag[i]==0 and  stop_semaphore[i]==0):
                         for k in range(lower-1,upper):
                          if(i!=k):    
                            #Comparing the selected drone of outer loop with respect to its row drones only        
                            ob2 = bpy.data.objects[drone[k]]
                            x2 = int(ob2.matrix_world.to_translation().x*100 * scale)
                            y2 = int(ob2.matrix_world.to_translation().y*100 * scale)
                            z2 = int(ob2.matrix_world.to_translation().z*100 * scale)
                            dx = x2 - x
                            dy = y2 - y
                            dz = z2 - z
                            d = math.sqrt(dx*dx + dy*dy + dz*dz)  
                            if(d < d_threshold):
                                if(((z>z2) or (z==z2 and i<k))):
                                    if(reached_flag[k]==0):    
                                       #print(drone[i]+"||"+drone[k]+"||"+str(round(d/100,2))+"||"+str(f)+"||"+'\n')
                                       stop_semaphore[i]=1
                                    
                                       ob.keyframe_insert(data_path="location", frame=f)
                                       ob.keyframe_insert(data_path="location", frame=f+stop_frame_period)
                                       stop_frame[i]=f+stop_frame_period

                                      
                                       ob.keyframe_delete(data_path="location", frame=land_frame[i])
                                       
                                       current_height= z/100
                                       current_x=x/100
                                       current_y=y/100
                                       ob.location.x = target_x
                                       ob.location.y = target_y
                                       ob.location.z = target_height # offset of 5
                                
                                       distance=((current_x-target_x)**2+(current_y-target_y)**2+(current_height-target_height)**2)**(1/2)
                                       time=distance/mytool.drone_speed
                                       f1_delay=24*time
                                       land_frame[i]= f+stop_frame_period+f1_delay 
                                       ob.keyframe_insert(data_path="location", frame=land_frame[i])
                                       break

                                       
            f=f+1  
            reached=min(reached_flag)
            # print("frame_tested="+str(f))
        print("\nlanding applied")
        return {'FINISHED'}

       