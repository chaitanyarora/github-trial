# Animation Tool
Drone light show software is the  animation toolbox as an add-on plugin in blender software. It consists of formation making strategies with a set of protocol to apply collision avoidance. The toolbox consists of formation and color panel to apply color on  multiple object(drone)  and multiple object(drone) on the vertex of the formation with a single-click.
 


## Installation Process
- [ ] Install latest blender software from blender.org
- [ ] Install scipy module through command prompt as an administrator
        
        1)"C:/>cd  Program Files/Blender Foundation/Blender 4.1/4.1/python/bin"
        
        2)python -m pip install scipy
- [ ] Download animation_tool.zip file of required version  in "https://gitlab.com/botlabdynamics/blender-plugin/animation-tool/-/releases"
- [ ] Install the animation_tool.zip as an add-on plugin in blender

## Animation Tool Test Report
[Animation Tool Test Report](https://docs.google.com/spreadsheets/d/19G9bZKLZ0_5jAEbrTettke40F3DPWD4OqcQMrH1CruA/edit?pli=1#gid=235145774)


